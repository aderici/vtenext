/*********************************************************************************
  ** The contents of this file are subject to the vtiger CRM Public License Version 1.0
   * ("License"); You may not use this file except in compliance with the License
   * The Original Code is:  vtiger CRM Open Source
   * The Initial Developer of the Original Code is vtiger.
   * Portions created by vtiger are Copyright (C) vtiger.
   * All Rights Reserved.
  *
 ********************************************************************************/

/* crmv@192033 */

function move_module(tabid,move) {
	jQuery.ajax({
		url: 'index.php',
		method: 'POST',
		data: 'module=CustomerPortal&action=CustomerPortalAjax&file=ListView&sub_mode=movemodules&parenttab=Settings&tabid='+tabid+'&move='+move+'&ajax=true',
		success: function(result) {
			jQuery("#portallist").html(result);
		}
	});	
}

function toggleModule(tabid, action) {
	var data = 'module=CustomerPortal&action=CustomerPortalAjax&file=ListView&tabid='+tabid+'&sub_mode=enable_disable&status='+action; 
	jQuery.ajax({
		url: 'index.php',
		method: 'POST',
		data: data,
		success: function(result) {
			// Reload the page to apply the effect of module setting
			window.location.href = "index.php?module=CustomerPortal&action=index&parenttab=Settings";
		}
	});
}
