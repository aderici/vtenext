<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'CustomerPortal' => 'Customer Portal',
'LBL_BASIC_SETTINGS'=>'Impostazioni Base',
'LBL_ADVANCED_SETTINGS'=>'Impostazioni Avanzate',
'LBL_MODULE'=>'Modulo',
'LBL_VIEW_ALL_RECORD'=>'Visualizzare tutti i Record ?',
'YES'=>'Si',
'NO'=>'No',
'LBL_USER_DESCRIPTION'=>'L\'Utente sopra selezionato gestir&agrave; i campi che appariranno nel Customer Portal.
				Si possono abilitare/disabilitare i campi da visualizzare nel Customer Portal.',
'SELECT_USERS'=>'Seleziona l\'Utente',				
'LBL_DISABLE'=>'Disabilita',
'LBL_ENABLE' =>'Abilita',
'Module' => 'Modulo',
'Sequence' =>'Sequenza',
'Visible'=>'Visibile',
//crmv@17713
'SELECT_TEMPLATE'=>'Seleziona il Template',
'LBL_TEMPLATE_DESCRIPTION'=>'Il Template selezionato sar&agrave; utilizzato per la mail di iscrizione al portale.',
//crmv@17713e
);
?>