/**********************************************************************************
* The contents of this file are subject to the vtiger CRM Public License Version 1.0
* ("License"); You may not use this file except in compliance with the License
* The Original Code is:  vtiger CRM Open Source
* The Initial Developer of the Original Code is vtiger.
* Portions created by vtiger are Copyright (C) vtiger.
* Portions created by CRMVILLAGE.BIZ are Copyright (C) CRMVILLAGE.BIZ.
* All Rights Reserved.
*********************************************************************************/

/* crmv@192033 */

loadFileJs('include/js/Merge.js');

function callRBSearch(searchtype)
{
	for(var i=1;i<=26;i++) {
		var data_td_id = 'alpha_'+ eval(i);
		getObj(data_td_id).className = 'searchAlph';
	}
	gPopupAlphaSearchUrl = '';
	search_fld_val = jQuery('#bas_searchfield').val();
	search_txt_val = document.basicSearch.search_text.value;
	var urlstring = '';
	if(searchtype == 'Basic')
	{
		urlstring = 'search_field='+search_fld_val+'&searchtype=BasicSearch&search_text='+search_txt_val+'&';
	}
	var selectedmodule = jQuery('#select_module').val();
	urlstring += 'selected_module='+selectedmodule;
	jQuery.ajax({
		url :'index.php',
		method: 'POST',
		data: urlstring +'&query=true&module=RecycleBin&action=RecycleBinAjax&file=index&ajax=true&mode=ajax',
		success: function(result) {
			jQuery("#status").hide();
			jQuery("#modules_datas").html(result);
			jQuery("#search_ajax").html('');
		}
	});
}

function changeModule(pickmodule)
{
	jQuery("#status").show();
	var module=pickmodule.options[pickmodule.options.selectedIndex].value;
	jQuery.ajax({
		url :'index.php',
		method: 'POST',
		data: 'action=RecycleBinAjax&module=RecycleBin&mode=ajax&file=ListView&selected_module='+module,
		success: function(result) {
			jQuery("#status").hide();
			jQuery("#modules_datas").html(result);
			jQuery("#searchAcc").html(jQuery("#search_ajax").html()); 
			jQuery("#search_ajax").html('');
		}
	});
}

function massRestore()
{
	var selectedmodule = jQuery('#select_module').val();
	idstring = get_real_selected_ids('RecycleBin').replace(/;/g,","); 
	if (idstring == "" || idstring == ",")
	{
		alert(mod_alert_arr.SELECT_ATLEAST_ONE_ENTITY);
		return false;
	}
	
	if (idstring.substr('0','1')==",")
	idstring = idstring.substr('1');
	var idarr = idstring.split(',');
	var count = idarr.length;
	var xx = count-1;
	if (xx > 1)
		var record = mod_alert_arr.RECORDS;
	else
		var record = mod_alert_arr.RECORD;	
	
	vteconfirm(mod_alert_arr.MSG_RESTORE_CONFIRMATION + " " + xx + " " + record + "?", function(yes) {
		if (yes) {
			jQuery("#status").show();
			jQuery.ajax({
				url :'index.php',
				method: 'POST',
				data: 'action=RecycleBinAjax&module=RecycleBin&mode=ajax&file=Restoration&idlist='+idstring+'&selectmodule='+selectmodule,
				success: function(result) {
					jQuery("#status").hide();
					jQuery("#modules_datas").html(result);
					jQuery("#search_ajax").html('');
				}
			});
		}
	});
}

function restore(entityid,select_module)
{
	vteconfirm(mod_alert_arr.MSG_RESTORE_CONFIRMATION + " " + mod_alert_arr.THE + " " + mod_alert_arr.RECORD + "?", function(yes) {
		if (yes) {
			jQuery("#status").show();
			jQuery.ajax({
				url :'index.php',
				method: 'POST',
				data: 'action=RecycleBinAjax&module=RecycleBin&mode=ajax&file=Restoration&entityid='+entityid+'&selectmodule='+select_module,
				success: function(result) {
					jQuery("#status").hide();
					jQuery("#modules_datas").html(result);
					jQuery("#search_ajax").html('');
				}
			});
		}
	});
}

function getListViewEntries_js(module,url)
{
	jQuery("#status").show();
	var selected_module = jQuery("#select_module").val();
	var urlstring='';
	if (isdefined('selected_ids'))
		urlstring += "&selected_ids=" + document.getElementById('selected_ids').value;
	if (isdefined('all_ids'))
		urlstring += "&all_ids=" + document.getElementById('all_ids').value;	
	urlstring += "&selected_module=" + selected_module;
	jQuery.ajax({
		url :'index.php',
		method: 'POST',
		data: "module=RecycleBin&action=RecycleBinAjax&file=ListView&mode=ajax&ajax=true&"+url+urlstring,
		success: function(result) {
			jQuery("#status").hide();
			jQuery("#modules_datas").html(result);
		}
	});
}

function alphabetic(module,url,dataid)
{
	for(var i=1;i<=26;i++) {
		var data_td_id = 'alpha_'+ eval(i);
		getObj(data_td_id).className = 'searchAlph';
	}
	var selectedmodule = jQuery("#select_module").val();
	url += '&selected_module='+selectedmodule;
		getObj(dataid).className = 'searchAlphselected';
	jQuery("#status").show();
	jQuery.ajax({
		url :'index.php',
		method: 'POST',
		data:"module="+module+"&action="+module+"Ajax&file=index&mode=ajax&ajax=true&"+url,
		success: function(result) {
			jQuery("#status").hide();
			jQuery("#modules_datas").html(result);
			jQuery("#search_ajax").html('');
		}
	});
}

function callEmptyRecyclebin() {
	vteconfirm(mod_alert_arr.MSG_EMPTY_RB_CONFIRMATION, function(yes) {
		if (yes) {
			emptyRecyclebin();
		}
	});
}

// crmv@164569
function emptyRecyclebin() {
	VtigerJS_DialogBox.progress();
	jQuery.ajax({
		url: "index.php?module=RecycleBin&action=RecycleBinAjax&file=EmptyRecyclebin&mode=ajax&ajax=true",
		method: 'POST',
		success: function(response) {
			jQuery("#status").hide();
			jQuery("#modules_datas").html(response);
			VtigerJS_DialogBox.hideprogress();
		}
	});
}
// crmv@164569e
