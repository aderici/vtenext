<?php
/*********************************************************************************
 *** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 ** ("License"); You may not use this file except in compliance with the License
 ** The Original Code is:  vtiger CRM Open Source
 ** The Initial Developer of the Original Code is vtiger.
 ** Portions created by vtiger are Copyright (C) vtiger.
 ** All Rights Reserved.
 **
 *********************************************************************************/

/* crmv@95157 */

require_once('modules/Documents/storage/StorageBackendUtils.php');
 
global $adb,$table_prefix;

//crmv@71058
$res = $adb->query('SELECT setype FROM '.$table_prefix.'_crmentity WHERE deleted=1 GROUP BY setype');
while($row = $adb->fetchByAssoc($res)){
	$focus = CRMEntity::getInstance($row['setype']);
	foreach($focus->tab_name_index as $table=>$key){
		if($table == $table_prefix.'_crmentity') continue;
		
		$query="DELETE $table FROM $table INNER JOIN {$table_prefix}_crmentity ON {$table_prefix}_crmentity.crmid = $table.$key WHERE deleted=1";
		$adb->query($query);
	}
}
//crmv@71058e

$adb->query('DELETE FROM '.$table_prefix.'_crmentity WHERE deleted = 1');
//TODO Related records for the module records deleted from vtiger_crmentity has to be deleted. 
//It needs lookup in the related tables and needs to be removed if doesn't have a reference record in vtiger_crmentity
 
$adb->query('DELETE FROM '.$table_prefix.'_relatedlists_rb');

// remove orphaned attachments
$SBU = StorageBackendUtils::getInstance();
$SBU->deleteOrphanAttachments();

// crmv@144125
// remove old entityname entries
$ENU = EntityNameUtils::getInstance();
$ENU->removeDeletedEntries();
// crmv@144125e

$parenttab = getParentTab();

header("Location: index.php?module=RecycleBin&action=RecycleBinAjax&file=index&parenttab=$parenttab&mode=ajax");
