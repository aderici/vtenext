<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$mod_strings = Array(
'RecycleBin' => 'Cestino',
'MSG_EMPTY_RB_CONFIRMATION'=>'Sicuro di voler rimuovere Permanentemente tutti i record eliminati dal database?',
'LBL_SELECT_MODULE'=>'Seleziona Modulo',
'LBL_EMPTY_MODULE'=>'Nessun record trovato da Ripristinare nel modulo',
'LBL_MASS_RESTORE'=>'Ripristina',
'LBL_EMPTY_RECYCLEBIN'=>'Svuota Cestino',
'LNK_RESTORE'=>'ripristina',
'LBL_NO_PERMITTED_MODULES'=>'Nessun modulo consentito disponibile',
);

?>