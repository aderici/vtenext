/*+********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ********************************************************************************/

var mod_alert_arr = {       
	SELECT_ATLEAST_ONE_ENTITY : 'Prego selezionare almeno una voce',
	MSG_RESTORE_CONFIRMATION : 'Sicuro di voler ripristinare ',
	RECORD : 'entit\u00E0 ',
	RECORDS : 'entit\u00E0 ',
	THE : 'l\' ',
	MSG_EMPTY_RB_CONFIRMATION: 'Sicuro di voler rimuovere Permanentemente tutti i record eliminati dal database?',
};
