var i18n = jQuery.extend({}, i18n || {}, {
    datepicker: {
        dateformat: {
            "fulldayvalue": "M/d/yyyy",
            "separator": "/",
            "year_index": 2,
            "month_index": 0,
            "day_index": 1,
            "sun": "So",
            "mon": "Mo",
            "tue": "Di",
            "wed": "Mi",
            "thu": "Do",
            "fri": "Fr",
            "sat": "Sa",
            "jan": "Jan",
            "feb": "Feb",
            "mar": "Mär",
            "apr": "Apr",
            "may": "Mai",
            "jun": "Jun",
            "jul": "Jul",
            "aug": "Aug",
            "sep": "Sep",
            "oct": "Okt",
            "nov": "Nov",
            "dec": "Dez",
            "postfix": ""
        },
        ok: " Ok ",
        cancel: "Löschen",
        today: "Heute",
        prev_month_title: "Vorheriger Monat",
        next_month_title: "Nächster Monat"
    }
});