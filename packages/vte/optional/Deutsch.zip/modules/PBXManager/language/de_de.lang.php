<?php
$mod_strings = array(
	'PBX Manager'=>'PBX Manager',
	'PBXManager'=>'PBX Manager',
	'SINGLE_PBXManager'=>'PBX Manager',
	'Status'=>'Status',
	'Asterisk'=>'Asterisk',
	'LBL_ASTERISK_INFORMATION'=>'ASTERISK Informationen',
	'Call From'=>'Anrufer',
	'Call To'=>'Angerufener',
	'Time Of Call'=>'Anrufzeit',
);
?>