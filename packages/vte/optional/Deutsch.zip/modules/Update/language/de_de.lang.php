<?php
$mod_strings = array(
	'LBL_CURRENT_VERSION'=>'Gegenwärtiger Aufbau',
	'LBL_UPDATE_PACK_INVALID'=>'Dieses Aktualisierungspaket wird durch Ihre VTE Version nicht unterstützt.<br/>Bitte kontaktieren Sie CRMVillage.BIZ oder Ihren Partner um die richtige Version zu erhalten.',
	'LBL_UPDATE'=>'Update',
	'LBL_UPDATE_DESC'=>'Update Version',
	'LBL_URL'=>'SVN address',
	'LBL_USERNAME'=>'Benutzer',
	'LBL_PASWRD'=>'Passwort',
	'LBL_SIGN_IN_DETAILS'=>'Login details',
	'LBL_SIGN_IN_CHANGE'=>'Login ändern',
	'LBL_MAX_VERSION'=>'zuletzt verfügbarer Aufbau',
	'LBL_UPDATE_DETAILS'=>'Update details',
	'LBL_UPDATE_BUTTON'=>'Update',
	'LBL_UPDATE_TO'=>'Update zu',
	'LBL_SPECIFIC_VERSION'=>'Version auswählen',
	'LBL_SPECIFICIED_VERSION'=>'Ausgewählte Version',
);
?>