<?php
$mod_strings = array(
	'SLA'=>'SLA Management',
	'SINGLE_SLA'=>'SLA Management',
	'LBL_SLA'=>'SLA Zeitpläne',
	'Time Elapsed'=>'Zeit abgelaufen',
	'Time remaining'=>'verbleibende Zeit',
	'SLA start date'=>'SLA Beginndatum',
	'SLA end date'=>'SLA Enddatum',
	'Update Time'=>'Zeitaktualisierung',
	'SLA Estimated Time'=>'SLA geschätzte Zeit',
	'Due Date'=>'Fälligkeitszeitpunkt',
	'Due Time'=>'Fälligkeitszeitpunkt (ss:mm)',
	'Time Last Status Change'=>'Letzte Zeitstatusänderung',
	'Time Elapsed Last Status Change'=>'Zeit vergangen seit letzter Statusänderung',
	'Reset SLA'=>'SLA Zurücksetzen',
	'End SLA'=>'SLA Ende',
	'Idle Time Elapsed'=>'inaktiv Zeit abgelaufen',
	'Out SLA Time Elapsed'=>'SLA Zeit abgelaufen',
);
?>