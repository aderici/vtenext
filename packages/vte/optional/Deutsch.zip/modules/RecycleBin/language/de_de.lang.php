<?php
$mod_strings = array(
	'RecycleBin'=>'Papierkorb',
	'MSG_EMPTY_RB_CONFIRMATION'=>'Sind Sie sicher, dass Sie die gelöschten Einträge entgültig aus Ihrem CRM entfernen wollen? Diese Aktion kann nicht rückgängig gemacht werden.',
	'LBL_SELECT_MODULE'=>'Modul auswählen',
	'LBL_EMPTY_MODULE'=>'Keine Einträge zum Wiederherstellen vorhanden. Modul: ',
	'LBL_MASS_RESTORE'=>'Wiederherstellen',
	'LBL_EMPTY_RECYCLEBIN'=>'Papierkorb leeren',
	'LBL_NO_PERMITTED_MODULES'=>'Keine autorisierten Module verfügbar',
	'LNK_RESTORE'=>'Wiederherstellen',
);
?>