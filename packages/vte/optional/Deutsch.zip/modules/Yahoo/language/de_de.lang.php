<?php
$mod_strings = array(
	'LBL_MODULE_NAME'=>'Organisationen',
	'LBL_MODULE_TITLE'=>'Organisationen: Home',
	'LBL_SEARCH_FORM_TITLE'=>'Organisationssuche',
	'LBL_LIST_FORM_TITLE'=>'Organisationsliste',
	'LBL_NEW_FORM_TITLE'=>'Neue Organisation',
	'ERR_DELETE_RECORD'=>'Bitte wählen Sie eine Datensatznummer, um den Account zu löschen.',
);
?>