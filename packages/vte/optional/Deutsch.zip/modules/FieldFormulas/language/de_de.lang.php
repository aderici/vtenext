<?php
$mod_strings = array(
	'LBL_NEW_FIELD_EXPRESSION_BUTTON'=>'Neuer Feldausdruck',
	'LBL_SELECT_ONE_DOTDOTDOT'=>'Eines auswählen...',
	'FieldFormulas'=>'Feldberechnungen',
	'LBL_FIELDFORMULAS'=>'Feldberechnungen',
	'LBL_FIELDFORMULAS_DESCRIPTION'=>'Fügen Sie Gleichungen zu benutzerdefinierten Feldern hinzu',
	'LBL_FIELDS'=>'Felder',
	'LBL_FUNCTIONS'=>'Funktionen',
	'LBL_FIELD'=>'Feld',
	'LBL_EXPRESSION'=>'Ausdruck',
	'LBL_SETTINGS'=>'Einstellungen',
	'LBL_EDIT_EXPRESSION'=>'Ausdruck bearbeiten',
	'LBL_MODULE_INFO'=>'Formeln festgelegt für',
	'LBL_CHECKING'=>'Prüfe...',
	'LBL_TARGET_FIELD'=>'Zielfeld',
	'LBL_DELETE_EXPRESSION_CONFIRM'=>'Sind Sie sicher, dass Sie diesen Ausdruck löschen wollen?',
	'LBL_EXAMPLES'=>'Beispiele',
	'LBL_USE_FIELD_VALUE_DASHDASH'=>'-- benutze Feldwert --',
	'LBL_USE_FUNCTION_DASHDASH'=>'-- benutze Funktion --',
	'NEED_TO_ADD_A'=>'Es besteht kein benutzerdefiniertes Feld. Um eines zu erstellen klicken Sie',
	'LBL_CUSTOM_FIELD'=>'hier',
);
?>