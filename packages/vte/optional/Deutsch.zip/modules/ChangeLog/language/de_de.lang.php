<?php
$mod_strings = array(
	'ChangeLog'=>'Änderungen des Benutzerkontos',
	'SINGLE_ChangeLog'=>'Änderungen des Benutzerkontos',
	'LBL_CHANGELOG_INFORMATION'=>'Verändere Log Informationen',
	'LBL_CUSTOM_INFORMATION'=>'benutzerdefinierte Informationen',
	'Audit No'=>'Keine Prüfung',
	'Assigned To'=>'zugewiesen zu',
	'Created Time'=>'Erstellt am',
	'Modified Time'=>'Änderungszeitpunkt',
	'Related To'=>'bezogen auf',
	'Modified fields'=>'Änderungen',
	'Modified by'=>'Geändert durch',
	'Field'=>'Feld',
	'Earlier value'=>'früherer Wert',
	'Actual value'=>'aktueller Wert',
	'LBL_LINKED_TO'=>'Wurde verbunden mit',
);
?>