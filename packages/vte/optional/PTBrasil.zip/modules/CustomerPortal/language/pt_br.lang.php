<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'CustomerPortal' => 'Portal do Cliente',
'LBL_BASIC_SETTINGS'=>'Configurações Básicas',
'LBL_ADVANCED_SETTINGS'=>'Configurações Avançadas',
'LBL_MODULE'=>'Módulo',
'LBL_VIEW_ALL_RECORD'=>'Visualizar Todos os Registros Relacionados?',
'YES'=>'Sim',
'NO'=>'Não',
'LBL_USER_DESCRIPTION'=>'O perfil do usuário selecionado acima irá gerenciar os campos mostrados no Portal do Cliente',
'SELECT_USERS'=>'Selecionar Usuários',				
'LBL_DISABLE'=>'Desabilitar',
'LBL_ENABLE' =>'Habilitar',
'Module' => 'Módulo',
'Sequence' =>'Sequência',
'Visible'=>'Visível',
//crmv@17713
'SELECT_TEMPLATE'=>'Seleciona o Modelo',
'LBL_TEMPLATE_DESCRIPTION'=>'O Modelo selecionado será utilizado pelo email de inscrição ao Portal Cliente.',
//crmv@17713e
);
?>