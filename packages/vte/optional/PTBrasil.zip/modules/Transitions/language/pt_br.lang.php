<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
*
 ********************************************************************************/

$mod_strings = array(
'LBL_STATUS_SAVE' => 'Atualizar',
'LBL_STATUS_CANCEL' => 'Voltar',
'LBL_STATUS_CURRENT_STATUS'=>'Status',
'LBL_STATUS_CHANGED_USER'=>"O Usuário",
'LBL_STATUS_CREATED'=>" Criado registro com Status", 
'LBL_STATUS_CHANGED_USER_FROM'=>" Foi modificado o Status", 
'LBL_STATUS_CHANGED_USER_TO'=>"em",
'LBL_STATUS_CHANGED_USER_ON'=>"na data",
'LBL_STATUS_CHANGED_MOTIVATION'=>"Nota :",
'LBL_STATUS_CAN_CHANGE_TO' =>"Pode modificar em :",
'LBL_STATUS_CAN_CHANGE_IF_FILL' => 'Para passar ao Status',
'LBL_STATUS_NO_AVAILABLE_STATES' =>'Nenhum status disponível',
'LBL_STATUS_MANDATORY_FIELDS' => 'É necessário preencher os Campos',
'LBL_STATUS_HIST_USER'=>'Usuário',
'LBL_STATUS_HIST_OLD_SALES_STAGE'=>'estado anterior',
'LBL_STATUS_HIST_NEW_SALES_STAGE'=>'próximo estado',
'LBL_STATUS_HIST_MOTIVATION'=>'Motivação',
'LBL_STATUS_HIST_LAST_MODIFIED'=>'Data e Hora última modificação',
'LBL_YOU_ARE_HERE'=>'',
'LBL_NO_DATA'=>'Nenhuma regra definida.',
'LBL_COPY'=>'Copia',
'LBL_MAKE_TRANSITION'=>'Inserir no Gerenciador',
'LBL_UNMAKE_TRANSITION'=>'não gerenciado',
'LBL_MANAGED'=>'[Gestido]',
'LBL_CANT_SET_FIELD'=>'Não é possível definir vários campos de estado!',
'LBL_STATUS_BLOCK_ACTUAL_STATE'=>'estado atual',
'LBL_CURR_ST_FIELD'=>'Campo de Status',
'LBL_INITIAL_STATE'=>'estado inicial',	//crmv@16604
'LBL_RESET_ALL'=>'remover seleção de todos',
'LBL_SELECT_ALL'=>'Selecionar todos',
'LBL_UPDATE'=>'Aplicar as modificações',
'LBL_ST_MANAGER'=>'Gerenciador Status',
'LBL_ST_MANAGER_DESCRIPTION'=>'Activar / Desactivar transições de status',
'LBL_ASSIGNABLE'=>'Usa para "Atribuído a"',
'Transitions History'=>'Histórico Status',
'LBL_STATUS_SAVE'=>'Enviar',
'LBL_STATUS_CANCEL'=>'Voltar',
//relatedlist fields
'HEADER_ID'=>'id',
'HEADER_OLD_STATUS'=>'velho status',
'HEADER_NEW_STATUS'=>'novo status',
'HEADER_USER'=>'usuário',
'HEADER_NOTE'=>'nota',
'HEADER_DATE'=>'data',
'Transitions'=>'Gerenciador Status',
'COPY_FROM'=>'Copiar da',	//crmv@16604
);

?>
