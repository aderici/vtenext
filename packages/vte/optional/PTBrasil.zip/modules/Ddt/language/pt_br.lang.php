<?php
$mod_strings = Array(
	'LBL_NEW_DDT' => 'Criar Documento de Frete',
	'Ddt' => 'Doc. Frete',
	'LBL_CUSTOM_INFORMATION' => 'Informações Personalizadas',
	'LBL_DDT_INFORMATION' => 'Informações Documento de Frete',
	'LBL_DESCRIPTION_INFORMATION'=>'Informação Descrição',
	'LBL_TERMS_INFORMATION' => 'Prazos e Condições',
	'SINGLE_Ddt' => 'Documento de Frete',
	'Add Invoice' => 'Criar Fatura',
	'Customer No' => 'Número Cliente',
	'--None--' => '--Nenhum--',
	'Ddt No'=>'Número Documento de Frete',	//crmv@18564
	'Condizione di Consegna'=>'Condição de Entrega',	//VTE br
	'Product Name'=>'Nome Produto',
	'Service Name'=>'Nome Serviço',
	'Quantity'=>'Quantidade',
	'Sub Total'=>'Total',
);
?>