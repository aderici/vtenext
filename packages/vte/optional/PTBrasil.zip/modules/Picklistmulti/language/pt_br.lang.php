<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *
 ********************************************************************************/
/**
 * this file can be used to internationalise the strings present in the picklist
 */
$mod_strings = array(
	'LBL_ASSIGN_BUTTON'=>'Atribuir',
	'ADD_PICKLIST_VALUES'=>'Adicionar valores Lista de Opções',
	'LBL_EXISTING_PICKLIST_VALUES'=>'Valores existentes Lista de Opções',
	'LBL_PICKLIST_ADDINFO'=>'Adicionar novas entradas aqui',
	'LBL_SELECT_ROLES'=>'Selecionar função',
	'LBL_NON_EDITABLE_PICKLIST_ENTRIES'=>'Valores não editáveis',
	'EDIT_PICKLIST_VALUE'=>'Editar valores Lista de Opções',
	'LBL_EDIT_HERE'=>'Substituir por: ',
	'LBL_SELECT_TO_EDIT'=>'Selecionar um valor para editar: ',
	'DELETE_PICKLIST_VALUES'=>'Apagar valores Lista de Opções',
	'LBL_REPLACE_WITH'=>'Substituir por: ',
	'ASSIGN_PICKLIST_VALUES'=>'Atribuir Valores Lista de Opções',
	'LBL_PICKLIST_VALUES'=>'Valores Lista de Opções disponíveis',
	'LBL_PICKLIST_VALUES_ASSIGNED_TO'=>'Valores Lista de Opções designados para ',
	'LBL_ADD_TO_OTHER_ROLES'=>'Adicionar outra Função',
	'LBL_OK_BUTTON_LABEL'=>'Ok',
	'LBL_SELECT_ROLES'=>'Selecionar Função',
	'LBL_DISPLAYED_VALUES'=>'Todos os valores acessíveis para a função apresentada abaixo',
	'LBL_ADD_VALUE' => 'Adicionar valor',
	'Code'=>'Código',
	'LBL_EMPTY'=>'Não tem valores',
	'LBL_ERROR_GENERIC'=>'Erro na operação',
	'LBL_SUCCESS'=>'Operação completada com sucesso',
	'LBL_CODE_NOT_UNIQUE'=>' O código não é unívoco! inserir um diferente!',
	'LBL_MANDATORY'=>'Os campos marcados com (*) são obrigatórios',
);
?>
