<?php
$mod_strings = Array(
	'LBL_NEW_TIMECARDS' => 'Criar Intervenção',
	'Timecards' => 'Intervenções',

	'LBL_DESCRIPTION_INFORMATION' => 'Informação Descrição',
	'LBL_CUSTOM_INFORMATION' => 'Informação Personalizada',
	'LBL_TIMECARD_INFORMATION' => 'Informação Intervenções',
	'LBL_TICKET_INFORMATION' => 'Informação Ticket',
	'SINGLE_Timecards' => 'Intervenção',

	'TCDate' => 'Data',
	'TCWorker' => 'Usuário',
	'TCUnits' => 'Unidade',
	'TCTime' => 'Tempo <i>(hh:mm)</i>',	//crmv@14132
    'Product' => 'Produto',
    'Description' => 'Descrição',
    'TCType' => 'Tipo',
    'Comment' => 'Comentário',
    'InvoiceLine' => 'Linha de Fatura',
    'BlockedComment' => 'Comentário bloqueado',
    'NewTC' => 'Nova Intervenção',
	'sortorder' => 'Ordem',
    'NewState' => 'Alterar o status de bilhetes para',
    'ReassignTicketTo' => 'Atribuir Ticket à',
	'LBL_CHANGE'=>'Mudar Responsável',
	'Maintain' => 'Manutenção',
    'LBL_ViewTC' => 'Visualizar Intervenções',
	'Product Name'=> 'Nome do Produto',

'LBL_TCMoveUp' => 'Mover sobre',
'LBL_TCMoveDown' => 'Mover abaixo',
'LBL_CONVERT_AS_SALESORDER_BUTTON_TITLE' => 'Converter em Pedido de Vendas',
'LBL_CONVERT_AS_SALESORDER_BUTTON_KEY' => 'S',
'LBL_CONVERT_AS_SALESORDER_BUTTON_LABEL' => 'Converter em Pedido de Vendas',
'LBL_PDF_WITH_COMMENTS' => 'Ticket com comentários',
'LBL_PDF_WITHOUT_COMMENTS' => 'Ticket sem comentários',
'LBL_HelpDesk_Receipt' => 'Formulários de Trabalho',
'MSG_NoSalesEntity' => 'Não Associados',
'ElapsedTime'=>'Tempo Transcorrido',
'FinishDate'=>'A data de término',
'TimeDedicated'=>'Tempo Dedicado',
'WorkMaterial'=>'Trabalho e Material',
'LBL_Days' => 'Dias',
'sortReturn'=>'Voltar',
'sortReturnKey'=>'V',
'sortClose'=>'Fechar',
'sortCloseKey'=>'X',
'sortReport'=>'Relatório', // Generar Listado 
'sortReportKey'=>'L',
'sortSeeWO'=>'Ver encomendas de trabalho', // Ver trabajos [Alt+V] 
'sortSeeWOKey'=>'V',
'sortUserNotDefined'=>'Usuários não definidos', // Usuario no definido
'sortWO'=>'Ordena Formularios', // Ordenaci&oacute;n de Trabajos Pendientes
'sortWOforUser'=>'Pedido Formulários de Trabalho ', // Ordenaci&oacute;n Trabajos Pendientes de
'sortNoWOPending'=>'Nehum Formulario Pendente', // No tiene trabajos pendientes
'sortPendingWO'=>'Formularios pendentes para Usúario ', // Trabajos Pendientes de
'sortOrder'=>'Ordem de classificação',
'sortTitle'=>'Titulo',
'sortMaterial'=>'Material',
'Err_NoAccountContact'=>'Não é possível converter porque o bilhete não está relacionado a um Contacto / Conta',
'Err_ContactWithoutAccount'=>'Não é possível converter porque o bilhete é relacionado a um contato que não esteja vinculada a uma conta',

'Created Time'=>'tempo criado',
'Modified Time'=>'Data e Hora de Modificação',
'Type'=>'Tipo',
);

?>
