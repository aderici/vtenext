<?php
$mod_strings = array (
	'LBL_UPDATE'=>'Atualização',
	'LBL_UPDATE_DESC'=>'Atualizar a versão',
	'LBL_URL'=>'Endereço SVN',
	'LBL_USERNAME'=>'Nome usuário',
	'LBL_PASWRD'=>'Senha',
	'LBL_SIGN_IN_DETAILS'=>'Detalhes Acesso',
	'LBL_SIGN_IN_CHANGE'=>'Mudar Acesso',
	'LBL_CURRENT_VERSION'=>'Build Atual',
	'LBL_MAX_VERSION'=>'Último build disponível',
	'LBL_UPDATE_DETAILS'=>'Detalhes Atualização',
	'LBL_UPDATE_BUTTON'=>'Atualizar',
	'LBL_UPDATE_TO'=>'Atualiza para',
	'LBL_SPECIFIC_VERSION'=>'Específica versão',
	'LBL_SPECIFICIED_VERSION'=>'Versão especificada',
	'LBL_UPDATE_PACK_INVALID'=>'Esta atualização não é suportado pela sua versão VTE. <br /> Por favor, entre em contato com CRMVillage.BIZ ou o seu parceiro para a versão correta.',
);
?>