<?php
$mod_strings = array (
  'LBL_ATTACH_FILE' => 'Anexar Arquivo',
  'LBL_ATTACH' => 'Anexo',
  'LBL_CANCEL' => 'Cancelar',
  'LBL_STEP_SELECT_FILE' => 'Passo 1 : Selecionar Arquivo',
  'LBL_BROWSE_FILES' => 'Clique no botão e selecione o arquivo a ser anexado',
  'LBL_DESCRIPTION' => 'Passo 2 : Escreva uma descrição',
  'LBL_OPTIONAL' => '(opcional)',

);
?>