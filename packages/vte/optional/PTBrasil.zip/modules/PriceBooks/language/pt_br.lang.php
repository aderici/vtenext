<?php
$mod_strings = array (
  'LBL_NEW_PRICEBOOKS' => 'Criar Lista de Preços',
  'LBL_PRICEBOOK_INFORMATION' => 'Informação Lista de Preços',
  'LBL_CUSTOM_INFORMATION' => 'Informação Personalizada:',
  'LBL_DESCRIPTION_INFORMATION' => 'Nome Descrição:',
  'Price Book Name' => 'Nome Lista de Preços',
  'Product Name' => 'Nome Produto',
  'Active' => 'Ativo',
  'Description' => 'Descrição',
  'Created Time' => 'tempo criado',
  'Modified Time' => 'Data e Hora de Modificação',
  'LBL_LIST_PRODUCT_NAME' => 'Nome Produto',
  'LBL_PRODUCT_CODE' => 'Código Produto',
  'LBL_PRODUCT_UNIT_PRICE' => 'Preço Unitário',
  'LBL_PB_LIST_PRICE' => 'Lista de Preços',
  'LBL_ACTION' => 'Ação',
  'PriceBook' => 'Lista de Preços',
// Added after 5.0.4 GA
'Currency'=>'Moeda',

// Module Sequence Numbering
'PriceBook No' => 'Número Lista de Preços',	//crmv@18564
// END
);
?>