<?php
$mod_strings = array (
	'LBL_WATERMARK'=>'Inserir um valor para pesquisar..',
	'LBL_NO_RECORDS'=>'Nenhum elemento foi encontrado!',
);
?>