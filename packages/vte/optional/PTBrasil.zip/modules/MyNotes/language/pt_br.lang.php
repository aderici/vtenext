<?php
$mod_strings = array(
	'MyNotes'=>'notas',
	'SINGLE_MyNotes'=>'nota',
	'LBL_MYNOTES_INFORMATION'=>'informações de Nota ',
	'Subject'=>'título',
	'Description'=>'nota',
	'Assigned To'=>'Atribuído a',
	'Created Time'=>'Tempo Criado ',
	'Modified Time'=>'Hora da Modificação',
);
?>