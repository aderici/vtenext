<?php
$mod_strings = Array(
/*some general information*/
'LBL_NEW_ASSETS' => 'Criar Instalação',
'LBL_MODULE_NAME'=>'Instalações',
'SINGLE_Assets'=>'Instalação',

/*blocks for the module*/
'LBL_ASSET_INFORMATION'=>'Informação Instalação',
'LBL_CUSTOM_INFORMATION'=>'Informação Personalizada',
'LBL_DESCRIPTION_INFORMATION'=>'Informação Descrição',

/*fields for the module*/
'Assets'=>'Instalações',
'Asset Name' => 'Nome Instalação',
'Customer Name'=>'Conta',
'Product Name'=>'Produto',
'Serial Number'=>'Número de Série',
'Asset No'=>' Número Instalação',
'Date Sold'=>'Data de Venda',
'Date in Service'=>'Data em Serviço',//asas
'Status'=>'Status',
'Shipping Method'=>'Método Entrega',
'Shipping Tracking Number'=>'Número Rastreamento Entrega',
'Tag Number'=>' Número Tag',
'Notes'=>'Notas',
'Invoice Name'=>'Nome Fatura',

/*picklist values*/
'In Service'=>'Em Serviço',
'Out-of-service'=>'Fora Serviço',


);
?>
