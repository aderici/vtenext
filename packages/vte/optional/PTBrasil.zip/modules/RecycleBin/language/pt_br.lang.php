<?php
$mod_strings = Array(
'RecycleBin' => 'Lixeira',
'MSG_EMPTY_RB_CONFIRMATION'=>'Você tem certeza que deseja remover os registros? Todos os registros serão apagados permanentemente de sua base de dados?',
'LBL_SELECT_MODULE'=>'Selecionar Módulo',
'LBL_EMPTY_MODULE'=>'Nenhum registro foi encontrado para ser restaurado no Módulo',
'LBL_MASS_RESTORE'=>'Restaurar',
'LBL_EMPTY_RECYCLEBIN'=>'Limpar Lixeira',
'LNK_RESTORE'=>'restaurar',
'LBL_NO_PERMITTED_MODULES'=>'Nenhum módulo autorizadas disponíveis',
);

?>