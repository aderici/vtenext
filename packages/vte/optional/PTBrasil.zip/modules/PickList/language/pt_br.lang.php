<?php
$mod_strings = array(
	'LBL_ASSIGN_BUTTON'=>'Atribuir',
	'ADD_PICKLIST_VALUES'=>'Adicionar valores Lista de Opções',
	'LBL_EXISTING_PICKLIST_VALUES'=>'Valores existentes Lista de Opções',
	'LBL_PICKLIST_ADDINFO'=>'Adicionar nova Entrada aqui',
//	'LBL_SELECT_ROLES'=>'Select roles',
	'LBL_NON_EDITABLE_PICKLIST_ENTRIES'=>'Valores não-editáveis',
	'EDIT_PICKLIST_VALUE'=>'Editar valores Lista de Opções',
	'LBL_EDIT_HERE'=>'Substituir por: ',
	'LBL_SELECT_TO_EDIT'=>'Selecionar um valor para editar: ',
	'DELETE_PICKLIST_VALUES'=>'Apagar valores Lista de Opções',
	'LBL_REPLACE_WITH'=>'Substituir por: ',
	'ASSIGN_PICKLIST_VALUES'=>'Atribuir Valores Lista de Opções',
	'LBL_PICKLIST_VALUES'=>'Valores Lista de Opções disponíveis',
	'LBL_PICKLIST_VALUES_ASSIGNED_TO'=>'Valores Lista de Opções atribuidos para ',
	'LBL_ADD_TO_OTHER_ROLES'=>'Adicionar outra Função',
	'LBL_OK_BUTTON_LABEL'=>'Ok',
	'LBL_SELECT_ROLES'=>'Selecionar função',
	'LBL_DISPLAYED_VALUES'=>'Todos os valores acessíveis para a função apresentada abaixo',
		'LBL_SUCCESS'=>'Operação concluída com êxito',
		'LBL_MANDATORY'=>'Os campos marcados com (*) são de preenchimento obrigatório',
);
?>
