<?php
$mod_strings = Array(
	'LBL_NEW_PROJECTPLAN' => 'Criar Planejamento',
  	'LBL_MODULE_NAME'=>'Planejamentos',
  	'LBL_MODULE_TITLE'=>'Planejamentos',
    'LBL_NEW_PROJECT'=>'Novo Planejamento',
    'LBL_PROJECTS'=>'Planejamentos',
    'LBL_PROJECT'=>'Planejamentos',
	'projectname' => 'Nome Planejamento',
    'projects' => 'Planejamentos',
    'project' => 'Planejamentos',
    //added this to translate the module name in the main app menu
    'ProjectPlan'=>'Planejamentos',
	'projectplans'=>'Planejamentos',
	'projectplan'=>'Planejamentos',
    //
    'SINGLE_ProjectPlan' => 'Planejamento',
    'LBL_CUSTOM_INFORMATION' => 'Informação Personalizada',
    'LBL_PROJECT_INFORMATION' => 'Informação Planejamento',
    'LBL_DESCRIPTION_INFORMATION' => 'Informação Descrição',
  
    'projectid' => 'ID Planejamento',  
    'Project ID'=>'ID Planejamento',
    'Assigned To' => 'Atribuído a',
    'Start Date' => 'Data Início',
	//crmv@521translation start
	'Target End Date' => 'Data de Conclusão prevista',
    'Actual End Date' => 'Data de Conclusão real',
    'Status'=>'Status',
    'Type'=>'Tipo',
    'Target Budget'=>'Custo Previsto',
    'Project Url'=>'Url do Planejamento',
    'Priority'=>'Prioridade do Planejamento;',
    'Progress'=>'Andamento',
	//crmv@521translation end
    'startdate' => 'Data Inicial', //CAMPO NON PRESENTE NELLA EN
    'targetenddate' => 'Data de Conclusão prevista', //CAMPO NON PRESENTE NELLA EN
    'actualenddate' => 'Data de Conclusão real', //CAMPO NON PRESENTE NELLA EN
    'projectstatus'=>'Status', //CAMPO NON PRESENTE NELLA EN 
    'projecttype'=>'Tipo', //CAMPO NON PRESENTE NELLA EN
    'linktoaccountscontacts'=>'Relacionado à', //CAMPO NON PRESENTE NELLA EN
    'targetbudget'=>'Custo', //CAMPO NON PRESENTE NELLA EN
    'projecturl'=>'Url do Planejamento', //CAMPO NON PRESENTE NELLA EN
    'projectpriority'=>'Prioridade do Planejamento', //CAMPO NON PRESENTE NELLA EN
    'progress'=>'Andamento', //CAMPO NON PRESENTE NELLA EN
    'additionalinformation'=>'Informações complementares', //CAMPO NON PRESENTE NELLA EN
    'linktopotentials'=>'Relacionado à', //CAMPO NON PRESENTE NELLA EN
    'Related To' => 'Relacionato à',
    'administrative' => 'administrativo',
    'operative' => 'operativo',
    'other' => 'outro',
    'low' => 'baixa',
    'normal' => 'normal',
    'high' => 'alta',
    'in progress' => 'em andamento',
    'in planning' => 'em planejamento',
    'on hold' => 'aguardando',
    'archived' => 'arquivado',
    'complete' => 'conclu�do',
    'Created Time' => 'tempo criado',
    'Modified Time' => 'Data e Hora de Modificação',
    'Description' => 'Descrição',
    'description' => 'Descrição',
    '--none--' => 'nenhum',
    'Deadline' => 'Marco',
    'Operation' => 'Atividade',
    'Project Name' => 'Nome Planejamento',
	//crmv@521translation start
    'LBL_RELATED_PROJECT_TASKS' => 'Tarefas',
    'LBL_RELATED_PROJECT_MILESTONES' => 'Marco Planejamento',
    
    'Charts' => 'Gráficos',
	'LBL_PROGRESS_CHART' => 'Gráfico Andamento',
	'Project No' => 'Número Planejamento',
	
	'Projects Plans' => 'Planejamentos',
	'Project Milestones' => 'Marco Planejamento',
	'Project Tasks' => 'Tarefas projeto',
	'Project Team' => 'Equipe',
	//crmv521@translation end

	//crmv@18828
	'Add Project Task'=>'Criar Tarefa',
	'Add Note'=>'Criar Documento',
	'Project Plans'=>'Planejamentos',
	//crmv@18828e
);

?>
