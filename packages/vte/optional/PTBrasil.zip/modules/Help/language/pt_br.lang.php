<?php
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Conta',
  'LBL_MODULE_TITLE' => 'Conta: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Conta',
  'LBL_LIST_FORM_TITLE' => 'Listar Conta',
  'LBL_NEW_FORM_TITLE' => 'Nova Conta',
  'ERR_DELETE_RECORD' => 'Por favor, especifique um número recorde para excluir a conta.',

);
?>