<?php
$mod_strings = Array (
'FieldFormulas' => 'Fórmulas Campos',
'LBL_FIELDFORMULAS' => 'Fórmulas Campos',
'LBL_FIELDFORMULAS_DESCRIPTION' => 'Adicionar equações personalizadas para campos personalizados',
'LBL_FIELDS' => 'Campos',
'LBL_FUNCTIONS' => 'Funções',
'LBL_FIELD' => 'Campo',
'LBL_EXPRESSION' => 'Expressão',
'LBL_SETTINGS' => 'Configurações',
'LBL_NEW_FIELD_EXPRESSION_BUTTON' => 'Nova Expressão Campo',
'LBL_EDIT_EXPRESSION' => 'Editar Expressão',
'LBL_MODULE_INFO' => 'Fórmulas definidas para',
'NEED_TO_ADD_A' =>'Você precisa adicionar uma série ou um número inteiro ',
'LBL_CUSTOM_FIELD' =>'Campo personalizado',
'LBL_CHECKING'=>'Verifica...',
'LBL_SELECT_ONE_DOTDOTDOT'=>'Selecione um...',
'LBL_TARGET_FIELD'=>'Campo Alvo',
'LBL_DELETE_EXPRESSION_CONFIRM'=>'Tem certeza de que deseja excluir a expressão?',
'LBL_EXAMPLES'=>'Exemplos',
'LBL_USE_FIELD_VALUE_DASHDASH'=>'-- usar valor campo --',
'LBL_USE_FUNCTION_DASHDASH'=>'-- usar função --',
);

?>