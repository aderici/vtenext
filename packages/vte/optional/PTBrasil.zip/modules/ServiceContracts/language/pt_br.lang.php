<?php
$mod_strings = Array (
'LBL_NEW_SERVICECONTRACTS' => 'Criar Serv. Contrato',
'Service Contracts' => 'Serv. Contrato',
'ServiceContracts' => 'Serv. Contrato',
'SINGLE_ServiceContracts' => 'Serv. Contrato',
'LBL_SERVICE_CONTRACT_INFORMATION' => 'Informação Serviço a Contrato',
'LBL_CUSTOM_INFORMATION' => 'Informação Personalizada',

'Contract No' => 'Número Contrato',
'Assigned To' => 'Atribuído a',
'Created Time' => 'tempo criado',
'Modified Time' => 'Data e Hora de Modificação',
'Start Date' => 'Data Início',
'Due date' => 'Data Vencimento',
'End Date' => 'Data Término',
'Related to' => 'Relacionado a',
'Tracking Unit' => 'Unidade Rastreamento',
'Total Units' => 'Unidades Totais',
'Used Units' => 'Unidades Utilizadas',
'Subject' => 'Assunto',
'Progress'=> 'Progresso (em %)',
'Type' => 'Tipo',
'Planned Duration' => 'Duração Planejada (em Dias)',
'Actual Duration' => 'Duração Atual (em Dias)',
'Status' => 'Status',
'Priority' => 'Prioridade;',

'Undefined' => 'Indefinido',
'In Planning' => 'Planejamento',
'In Progress' => 'Andamento',
'On Hold' => 'Aguardando',
'Complete' => 'Concluído',
'Archived' => 'Arquivado',

'Support' => 'Suporte',
'Services' => 'Serviços',
'Service' => 'Serviço',	//crmv@19387
'Administrative' => 'Administrativo',

'Low'=>'Baixo',
'Normal'=>'Normal',
'High'=>'Alto',

'None'=>'Nada',
'Hours'=>'Horas',
'Days'=>'Dias',
'Incidents'=>'Incidentes',
/*
 * 5.2.0 changes 
 */
'LBL_MODULE_NAME'=>'Serv. a Contrato',
'Residual Units'=>'Unidades Resíduas',	//crmv@19400
);

?>
