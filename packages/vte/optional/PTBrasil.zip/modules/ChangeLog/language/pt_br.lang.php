<?php
$mod_strings = array(
	'ChangeLog'=>'Change Log',
	'SINGLE_ChangeLog'=>'Change Log',
	'LBL_CHANGELOG_INFORMATION'=>'Alterar informações de log',
	'LBL_CUSTOM_INFORMATION'=>'Informação Customizada',
	'Audit No'=>'Codigo Revisão',
	'Assigned To'=>'Responsável',
	'Created Time'=>'tempo criado',
	'Modified Time'=>'Hora Modificação',
	'Related To'=>'Relacionado à',
	'Modified fields'=>'Alterações',
	'Modified by'=>'Modificado da',
	'Field'=>'Campo',
	'Earlier value'=>'Valor anterior',
	'Actual value'=>'Valor atual',
	'LBL_LINKED_TO'=>'foi ligado a',
);
?>