<?php
$mod_strings = array(
	'Actual value'=>'Huidige waarde',
	'Assigned To'=>'Toegewezen aan',
	'Audit No'=>'Audit Nr.',
	'ChangeLog'=>'Wijzig log',
	'SINGLE_ChangeLog'=>'Wijzig log',
	'LBL_CHANGELOG_INFORMATION'=>'Wijzig Log gegevens',
	'Modified fields'=>'Wijzigingen',
	'Created Time'=>'Aangemaakt om',
	'LBL_CUSTOM_INFORMATION'=>'Notities',
	'Earlier value'=>'Reeds gebruikte waarde',
	'Field'=>'Veld',
	'LBL_LINKED_TO'=>'Is gekoppeld aan',
	'Modified by'=>'Aangepast door',
	'Modified Time'=>'Tijdstip gewijzigd',
	'Related To'=>'gekoppeld aan',
);
?>