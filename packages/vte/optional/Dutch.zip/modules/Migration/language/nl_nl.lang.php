<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = Array(
	'LBL_MIGRATE_INFO'=>'Geef waarden in om data te migreren van <b><i> Source </i></b> to <b><i> Current (Latest) vtigerCRM </i></b>',
	'LBL_CURRENT_VT_MYSQL_EXIST'=>'Huidige vtiger\'s MySQL bestaat reeds in',
	'LBL_THIS_MACHINE'=>'Deze computer',
	'LBL_DIFFERENT_MACHINE'=>'Andere computer',
	'LBL_CURRENT_VT_MYSQL_PATH'=>'Huidige vtiger\'s MySQL pad',
	'LBL_SOURCE_VT_MYSQL_DUMPFILE'=>'vtiger <b>Source</b> Dump beatndsnaam',
	'LBL_NOTE_TITLE'=>'Opmerking:',
	'LBL_NOTES_LIST1'=>'Als het huidige MySQL bestand al op deze computer aanwezig is, geef dan het MySQL pad in (of) geef de Dump bestandsnaam in (indien aanwezig).',
	'LBL_NOTES_LIST2'=>'Als het huidige MySQL bestandl op een andere computer aanwezig is, geef dan de Dump bestandsnaam met het volledige pad in.',
	'LBL_NOTES_DUMP_PROCESS'=>'Voor een Database dump, voer de volgende commandos uit binnen de mysql/bin directory',
	'LBL_NOTES_LIST3'=>'Voer het MySQL pad in als <b>/home/crm/vtigerCRM4_5/mysql</b>',
	'LBL_NOTES_LIST4'=>'Voer de Dump bestandsnaam in met het volledige pad als <b>/home/fullpath/4_2_dump.txt</b>',
	'LBL_CURRENT_MYSQL_PATH_FOUND'=>'Het bestaande MySQL pad is gevonden.',
	'LBL_SOURCE_HOST_NAME'=>'Bron Host naam:',
	'LBL_SOURCE_MYSQL_PORT_NO'=>'Bron MySql poort nr:',
	'LBL_SOURCE_MYSQL_USER_NAME'=>'Bron MySql gebruikersnaam:',
	'LBL_SOURCE_MYSQL_PASSWORD'=>'Bron MySql wachtwoord:',
	'LBL_SOURCE_DB_NAME'=>'Bron Database naam:',
	'LBL_MIGRATE'=>'Migreer naar huidige versie',
	'LBL_UPGRADE_VTIGER'=>'Upgrade vtiger CRM Database',
	'LBL_UPGRADE_FROM_VTIGER_423'=>'Upgrade database van vtiger CRM 4.2.3 naar 5.0.0',
	'LBL_SETTINGS'=>'Instellingen',
	'LBL_STEP'=>'Stap',
	'LBL_SELECT_SOURCE'=>'Selecteer bron',
	'LBL_STEP1_DESC'=>'Om de database migratie te starten dient u hetbestandsformaat van de oude data op te geven.',
	'LBL_RADIO_BUTTON1_TEXT'=>'Ik heb toegang tot het vtiger CRM live database systeem',
	'LBL_RADIO_BUTTON1_DESC'=>'Hiervoor heeft het adres en DB toegansgegevens nodig van de host computer (waarop de DB zich bevindt). Zowel de locale als de remote systemen worden hierdoor ondersteund. Help is beschbaar in de dokumentatie.',
	'LBL_RADIO_BUTTON2_TEXT'=>'Ik heb toegang tot de vtiger CRM opgeslagen database dump.',
	'LBL_RADIO_BUTTON2_DESC'=>'Hiervoor dient de database dump lokaal beschikbaar te zijn op dezelfde computer die u wilt upgraden. U kunt de data dump niet vanaf een andere computer beeiken (remote database server). Help is beschikbaar in de dokumentatie.',
	'LBL_RADIO_BUTTON3_TEXT'=>'Ik heb een nieuwe database met 4.2.3 data',
	'LBL_RADIO_BUTTON3_DESC'=>'Hiervoor heeft u de vtiger CRM 4.2.3 database systeem gegevens nodig, inclusief de database server ID, gebruikersnaam en wachtwoord.. U kunt de data dump net vanaf een andere computer bereiken (remote database server).',
	'LBL_HOST_DB_ACCESS_DETAILS'=>'Host Database toegangsgegevens',
	'LBL_MYSQL_HOST_NAME_IP'=>'MySQL Host Naam of IP Adres : ',
	'LBL_MYSQL_PORT'=>'MySQL Poort Nummer : ',
	'LBL_MYSQL_USER_NAME'=>'MySql gebruikersnaam: ',
	'LBL_MYSQL_PASSWORD'=>'MySql wachtwoord: ',
	'LBL_DB_NAME'=>'Database Naam: ',
	'LBL_LOCATE_DB_DUMP_FILE'=>'Vind Database Dump bestand',
	'LBL_DUMP_FILE_LOCATION'=>'Dump bestand Locatie: ',
	'LBL_RADIO_BUTTON3_PROCESS'=>'A.u.b. geen 4.2.3 database gegevens aanmaken. Dit zal de database direct wijzigen. Volg de volgende procedure. 1.maak een dump van de 4.2.3 database 2. Maak een nieuwe database aan  (het beste is om de database aan te maken op de server waar de vtiger 5.0 Database zich bevindt) 3. Kopieer de 4.2.3 dump naar deze nieuwe database. Maak de toegangsgegevens aan voor de nieuwe database. Deze migratie wijzigt de Database naar de 5.0 voorwaarden. Hierna kunt u de database een naam geven in het  config.inc.php bestand. Bijv. $dbconfig[\'db_name\'] = new db name',
	'LBL_ENTER_MYSQL_SERVER_PATH'=>'Geef het MySQL Server Pad in',
	'LBL_SERVER_PATH_DESC'=>'MySQL pad op de srever als <b>/home/5beta/vtigerCRM5_beta/mysql/bin</b> or <b>c:',
	'LBL_MYSQL_SERVER_PATH'=>'MySQL Server Pad : ',
	'LBL_MIGRATE_BUTTON'=>'migreren',
	'LBL_CANCEL_BUTTON'=>'Annuleren',
	'LBL_UPGRADE_FROM_VTIGER_5X'=>'Upgrade database van vtiger CRM 5.x naar de volgemde versie',
	'LBL_PATCH_OR_MIGRATION'=>'Geef de bron database versie op (Pad, update of Migratie)',
	'ENTER_SOURCE_HOST'=>'Geef de bron Host naam in',
	'ENTER_SOURCE_MYSQL_PORT'=>'Geef het bron MySql poort nummer in',
	'ENTER_SOURCE_MYSQL_USER'=>'Geef de bron MySql gebruikersnaam in',
	'ENTER_SOURCE_DATABASE'=>'Geef de bron Database naam in',
	'ENTER_SOURCE_MYSQL_DUMP'=>'Geef het geldige MySql dump bestand in',
	'ENTER_HOST'=>'Geef de Host Naam in',
	'ENTER_MYSQL_PORT'=>'Geef het MySql poort nummer in',
	'ENTER_MYSQL_USER'=>'Geef de MySql gebruikersnaam in',
	'ENTER_DATABASE'=>'Geef de Database naam in',
	'SELECT_ANYONE_OPTION'=>'Kies een optie',
	'ENTER_CORRECT_MYSQL_PATH'=>'Geef het juiste MySql pad in',
);
?>