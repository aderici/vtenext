<?php
$mod_strings = array(
	'LBL_PICKLIST_ADDINFO'=>'Nieuwe invoer',
	'ADD_PICKLIST_VALUES'=>'Waarde aan keuzelijst  toevoegen',
	'LBL_ADD_TO_OTHER_ROLES'=>'Aan overige functies toevoegen',
	'LBL_DISPLAYED_VALUES'=>'Zie onderstaande beschikbare waarden voor de functie ',
	'LBL_ASSIGN_BUTTON'=>'Toewijzen',
	'ASSIGN_PICKLIST_VALUES'=>'Wijs keuzelijsten waarden toe',
	'LBL_PICKLIST_VALUES_ASSIGNED_TO'=>'Toegewezen waarden keuzelijst voor',
	'LBL_PICKLIST_VALUES'=>'Beschikbare keuzelijst waarden',
	'DELETE_PICKLIST_VALUES'=>'Verwijder keuzelijstwaarden',
	'EDIT_PICKLIST_VALUE'=>'Wijzig keuzelijst waarden',
	'LBL_EXISTING_PICKLIST_VALUES'=>'Bestaande keuzelijst waarden',
	'LBL_NON_EDITABLE_PICKLIST_ENTRIES'=>'Vaste waarden',
	'LBL_OK_BUTTON_LABEL'=>'OK',
	'LBL_EDIT_HERE'=>'Vervang door',
	'LBL_REPLACE_WITH'=>'Vervang door',
	'LBL_SELECT_TO_EDIT'=>'Selecteer een waarde om aan te passen: ',
	'LBL_SELECT_ROLES'=>'Selecteer functies',
);
?>