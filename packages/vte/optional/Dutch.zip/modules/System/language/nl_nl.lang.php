<?php
$mod_strings = array(
	'LBL_SYSTEM_CONFIG'=>'Systeem configuratie',
);
?>