<?php
$mod_strings = array(
'LBL_NEW_PRODUCTLINES' => 'Aanmaken Product groep',
'ProductLines'=>'Product groepen',
'SINGLE_ProductLines'=>'Product groep',
'LBL_PRODUCTLINES_INFORMATION'=>'Product groep informatie',
'LBL_CUSTOM_INFORMATION'=>'Vrij veld',
'LBL_DESCRIPTION_INFORMATION'=>'Omschrijving',
'ProductLineName'=>'Regel naam',
);
?>