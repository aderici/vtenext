<?php
$mod_strings = array(
	'Due Date'=>'Geplande einddatum',
	'Due Time'=>'Geplande eindtijd (uu:mm)',
	'End SLA'=>'Einde van SLA',
	'Idle Time Elapsed'=>'Inactieve tijd verstreken',
	'Out SLA Time Elapsed'=>'SLA tijd verstreken',
	'Reset SLA'=>'Reset SLA',
	'SLA end date'=>'SLA einddatum',
	'SLA Estimated Time'=>'SLA begrootte tijd',
	'SLA'=>'SLA Management',
	'SINGLE_SLA'=>'SLA Management',
	'SLA start date'=>'SLA startdatum',
	'LBL_SLA'=>'SLA timing',
	'Time Elapsed'=>'Tijd verstreken',
	'Time Elapsed Last Status Change'=>'Tijd verstreken na laatste statuswijziging',
	'Time Last Status Change'=>'Tijd laatste statuswijziging',
	'Time remaining'=>'Resterende tijd',
	'Update Time'=>'Update tijd',
);
?>