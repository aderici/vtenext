<?php
$mod_strings = array(
	'LBL_USE_FIELD_VALUE_DASHDASH'=>'--Gebruik veldwaarde--',
	'LBL_USE_FUNCTION_DASHDASH'=>'--Gebruik functie--',
	'LBL_FIELDFORMULAS_DESCRIPTION'=>'Voeg formule aan vrij veld toe',
	'LBL_DELETE_EXPRESSION_CONFIRM'=>'Weet u zeker dat u de ???? wilt verwijderen?',
	'LBL_CHECKING'=>'Bezig…',
	'LBL_CUSTOM_FIELD'=>'Vrij veld',
	'LBL_EDIT_EXPRESSION'=>'Wijzig formule',
	'LBL_EXAMPLES'=>'Voorbeelden',
	'LBL_EXPRESSION'=>'Uitdrukking',
	'LBL_FIELD'=>'Veld',
	'FieldFormulas'=>'Veldformules',
	'LBL_FIELDFORMULAS'=>'Veldformules',
	'LBL_FIELDS'=>'Velden',
	'LBL_MODULE_INFO'=>'Formule voor',
	'LBL_FUNCTIONS'=>'Functie',
	'LBL_NEW_FIELD_EXPRESSION_BUTTON'=>'Nieuwe Field Expression',
	'LBL_SELECT_ONE_DOTDOTDOT'=>'Selecteer een',
	'LBL_SETTINGS'=>'Instellingen',
	'LBL_TARGET_FIELD'=>'Veld (doel)',
	'NEED_TO_ADD_A'=>'Voeg een string of integer type toe',
);
?>