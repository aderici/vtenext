<?php
$mod_strings = array(
	'ERR_DELETE_RECORD'=>'Geef een recordnummer op om de relatie te verwijderen',
	'LBL_LIST_FORM_TITLE'=>'Lijst van relaties',
	'LBL_SEARCH_FORM_TITLE'=>'Zoeken op relatienaam',
	'LBL_MODULE_NAME'=>'Relaties',
	'LBL_MODULE_TITLE'=>'Relaties: Home',
	'LBL_NEW_FORM_TITLE'=>'Nieuwe relatie',
);
?>