<?php
$mod_strings = array (
	'LBL_ATTACH_FILE'=>'Voeg bestand toe',
	'LBL_ATTACH'=>'Toevoegen',
	'LBL_CANCEL'=>'annuleren',
	'LBL_STEP_SELECT_FILE'=>'Stap 1: Selecteer het bestand',
	'LBL_BROWSE_FILES'=>'Klik op "browse" en selecteer het bestand dat u wilt toevoegen',
	'LBL_DESCRIPTION'=>'Stap 2: Geef een omschrijving',
	'LBL_OPTIONAL'=>'(optie)',
);
?>