<?php
$mod_strings = array(
	'LBL_NEW_PBXMANAGER' => 'Aanmaken PBX Manager',
	'Asterisk'=>'Asterisk',
	'LBL_ASTERISK_INFORMATION'=>'Asterisk informatie',
	'Call From'=>'Bellen vanuit',
	'Call To'=>'Bellen naar',
	'PBX Manager'=>'PBX Manager',
	'PBXManager'=>'PBX Manager',
	'SINGLE_PBXManager'=>'PBX Manager',
	'Time Of Call'=>'Gespreksduur',
);
?>