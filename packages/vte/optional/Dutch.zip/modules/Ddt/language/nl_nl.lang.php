<?php
$mod_strings = array(
	'LBL_NEW_DDT' => 'Aanmaken Ddt',
	'--None--'=>'--Leeg--',
	'Add Invoice'=>'Factuur toevoegen',
	'LBL_CUSTOM_INFORMATION'=>'Notities',
	'Customer No'=>'Klantnr.',
	'Ddt'=>'Ddt',
	'SINGLE_Ddt'=>'Ddt',
	'LBL_DDT_INFORMATION'=>'Ddt informatie',
	'Ddt No'=>'Ddt nr.',
	'LBL_DESCRIPTION_INFORMATION'=>'Omschrijving',
	'LBL_TERMS_INFORMATION'=>'Voorwaarden',
	'Product Name'=>'Productnaam',
	'Service Name'=>'Service naam',
	'Quantity'=>'Aantallen',
	'Sub Total'=>'Totaal',
);
?>