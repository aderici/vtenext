<?php
$mod_strings = array(
	'ERR_DELETE_RECORD'=>'Geef een recordnummer op om de relatie te verwijderen',
	'LBL_MODULE_NAME'=>'Administratie',
	'LBL_MODULE_TITLE'=>'Administratie: Home',
	'LBL_NEW_FORM_TITLE'=>'Nieuwe relatie',
);
?>