<?php
$mod_strings = array(
	'Geolocalization'=>'Geolokalizacja',
);
?>