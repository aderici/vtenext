<?php
$mod_strings = array(
	'Active'=>'Aktywny',
	'Created Time'=>'Utworzony czas',
	'Currency'=>'Waluta',
	'Description'=>'Opis',
	'LBL_ACTION'=>'Akcja',
	'LBL_CUSTOM_INFORMATION'=>'Informacje spersonalizowane',
	'LBL_DESCRIPTION_INFORMATION'=>'Opis nazwy:',
	'LBL_LIST_PRODUCT_NAME'=>'Nazwa produktu',
	'LBL_PB_LIST_PRICE'=>'Lista cen',
	'LBL_PRICEBOOK_INFORMATION'=>'Informacje o liście cen:',
	'LBL_PRODUCT_CODE'=>'Numer serii',
	'LBL_PRODUCT_UNIT_PRICE'=>'Cena jednostkowa',
	'Modified Time'=>'Zmieniony czas',
	'Price Book Name'=>'Nazwa listy cen',
	'PriceBook'=>'Lista cen',
	'PriceBook No'=>'Numer listy cen',
	'Product Name'=>'Nazwa produktu',
	'PriceBooksPrices'=>'Ceny Książki cenowej',
);
?>