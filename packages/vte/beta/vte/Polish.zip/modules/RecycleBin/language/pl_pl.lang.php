<?php
$mod_strings = array(
	'LBL_EMPTY_MODULE'=>'Nie znaleziono rekordówdo przywrócenia w module',
	'LBL_EMPTY_RECYCLEBIN'=>'Kosz pusty',
	'LBL_MASS_RESTORE'=>'Przywróć',
	'LBL_NO_PERMITTED_MODULES'=>'Brak dozwolonych modułów',
	'LBL_SELECT_MODULE'=>'Wybierz moduł',
	'LNK_RESTORE'=>'przywróć',
	'MSG_EMPTY_RB_CONFIRMATION'=>'Czy na pewno chcesz trwale usunąć wszystkie usunięte rekordy z bazy danych?',
	'RecycleBin'=>'Kosz',
);
?>