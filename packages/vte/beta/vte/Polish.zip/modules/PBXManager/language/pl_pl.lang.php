<?php
$mod_strings = array(
	'Asterisk'=>'Asterysk',
	'Call From'=>'Połączenie od',
	'Call To'=>'Połączenie z',
	'LBL_ASTERISK_INFORMATION'=>'Asterysk informacje',
	'PBX Manager'=>'Zarządzanie połączeniami',
	'PBXManager'=>'Zarządzanie połączeniami',
	'SINGLE_PBXManager'=>'Zarządzanie połączeniami',
	'Status'=>'Status',
	'Time Of Call'=>'Czas połączenia',
);
?>