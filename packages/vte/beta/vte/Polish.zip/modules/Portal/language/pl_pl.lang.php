<?php
$mod_strings = array(
	'LBL_ADD'=>'Dodaj',
	'LBL_BOOKMARK'=>'Zakładka',
	'LBL_BOOKMARKED_URL'=>'Zakładki',
	'LBL_BOOKMARK_LIST'=>'Lista zakładek',
	'LBL_BOOKMARK_NAME_URL'=>'Nazwa i URL zakładki',
	'LBL_MANAGE_BOOKMARKS'=>'Zarządzaj zakładkami',
	'LBL_MANAGE_SITES'=>'Zarządzaj stronami',
	'LBL_MY_BOOKMARKS'=>'Moje zakładki',
	'LBL_MY_SITES'=>'Strony',
	'LBL_NAME'=>'Nazwa:',
	'LBL_NEW_BOOKMARK'=>'Nowa zakładka',
	'LBL_SET_DEFAULT_BUTTON'=>'Ustaw jako domyślny',
	'LBL_SNO'=>'#',
	'LBL_TOOLS'=>'Narzędzia',
	'LBL_URL'=>'URL:',
);
?>