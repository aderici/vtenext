<?php
$mod_strings = array(
	'LBL_NO_RECORDS'=>'Nie znaleziono elementów!',
	'LBL_WATERMARK'=>'Wprowadź wartość, aby wyszukać…',
);
?>