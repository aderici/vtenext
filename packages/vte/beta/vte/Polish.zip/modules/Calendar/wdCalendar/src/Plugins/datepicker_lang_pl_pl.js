var i18n = jQuery.extend({}, i18n || {}, {
    datepicker: {
        dateformat: {
            "fulldayvalue": "M/d/yyyy",
            "separator": "/",
            "year_index": 2,
            "month_index": 0,
            "day_index": 1,
            "sun": "Nd.",
            "mon": "Pn",
            "tue": "Wt",
            "wed": "Śr",
            "thu": "Czw",
            "fri": "Pt",
            "sat": "So",
            "jan": "Sty",
            "feb": "Lut",
            "mar": "Mar",
            "apr": "Kwi",
            "may": "Maj",
            "jun": "Cze",
            "jul": "Lip",
            "aug": "Sie",
            "sep": "Wrz",
            "oct": "Paź",
            "nov": "Lis",
            "dec": "Gru",
            "postfix": ""
        },
        ok: " Ok ",
        cancel: "Anuluj",
        today: "Dzisiaj",
        prev_month_title: "poprzedni miesiąc",
        next_month_title: "następny miesiąc"
    }
});

