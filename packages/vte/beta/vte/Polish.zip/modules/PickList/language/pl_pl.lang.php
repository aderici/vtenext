<?php
$mod_strings = array(
	'ADD_PICKLIST_VALUES'=>'Dodaj wartości piklisty',
	'ASSIGN_PICKLIST_VALUES'=>'Przypisz wartości piklisty',
	'DELETE_PICKLIST_VALUES'=>'Usuń wartości piklisty',
	'EDIT_PICKLIST_VALUE'=>'Edytuj wartości piklisty',
	'LBL_ADD_TO_OTHER_ROLES'=>'Dodaj do innych ról',
	'LBL_ASSIGN_BUTTON'=>'Przypisz wartości piklisty',
	'LBL_DISPLAYED_VALUES'=>'Wszystkie dostępne wartości dla roli są wyświetlone poniżej',
	'LBL_EDIT_HERE'=>'Wymień na:',
	'LBL_EXISTING_PICKLIST_VALUES'=>'Istniejące wartości piklisty',
	'LBL_NON_EDITABLE_PICKLIST_ENTRIES'=>'Wartości niezmienialne',
	'LBL_OK_BUTTON_LABEL'=>'OK',
	'LBL_PICKLIST_ADDINFO'=>'Dodaj nowe wpisy tutaj',
	'LBL_PICKLIST_VALUES'=>'Dostępne wartości piklisty',
	'LBL_PICKLIST_VALUES_ASSIGNED_TO'=>'Przypisz wartości piklisty dla',
	'LBL_REPLACE_WITH'=>'Wymień na:',
	'LBL_SELECT_ROLES'=>'Wybierz role',
	'LBL_SELECT_TO_EDIT'=>'Wybierz wartość dozmiany:',
);
?>