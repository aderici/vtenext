<?php
$mod_strings = array(
	'ERR_DELETE_RECORD'=>'Aby usunąć firmę, podaj numer rekordu.',
	'LBL_MODULE_NAME'=>'Administrator',
	'LBL_MODULE_TITLE'=>'Administrator: Strona domowa',
	'LBL_NEW_FORM_TITLE'=>'Nowa firma',
);
?>