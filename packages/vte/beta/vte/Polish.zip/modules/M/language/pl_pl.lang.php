<?php
$mod_strings = array(
	'Mobile'=>'Telefon komórkowy',
);
?>