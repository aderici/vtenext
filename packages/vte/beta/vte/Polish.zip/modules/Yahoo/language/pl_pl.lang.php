<?php
$mod_strings = array(
	'ERR_DELETE_RECORD'=>'Wybierz numer rekordu, aby usunąć konto.',
	'LBL_LIST_FORM_TITLE'=>'Lista firm',
	'LBL_MODULE_NAME'=>'Firmy',
	'LBL_MODULE_TITLE'=>'Firmy: Strona domowa',
	'LBL_NEW_FORM_TITLE'=>'Nowa firma',
	'LBL_SEARCH_FORM_TITLE'=>'Szukaj firmy',
);
?>