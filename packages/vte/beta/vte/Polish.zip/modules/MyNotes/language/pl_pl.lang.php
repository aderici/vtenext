<?php
$mod_strings = array(
	'Assigned To'=>'Przypisany do',
	'Created Time'=>'Utworzony czas',
	'Description'=>'Notatka',
	'LBL_MYNOTES_INFORMATION'=>'Informacja',
	'Modified Time'=>'Zmieniony czas',
	'MyNotes'=>'Notatki',
	'SINGLE_MyNotes'=>'Notatka',
	'Subject'=>'Tytuł',
);
?>