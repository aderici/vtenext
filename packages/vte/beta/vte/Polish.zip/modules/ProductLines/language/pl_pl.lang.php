<?php
$mod_strings = array(
	'LBL_CUSTOM_INFORMATION'=>'Informacje spersonalizowane',
	'LBL_DESCRIPTION_INFORMATION'=>'Opis',
	'LBL_PRODUCTLINES_INFORMATION'=>'Informacje o linii produktów',
	'ProductLineName'=>'Nazwa linii',
	'ProductLines'=>'Linie produktu',
	'SINGLE_ProductLines'=>'Linie produktu',
);
?>