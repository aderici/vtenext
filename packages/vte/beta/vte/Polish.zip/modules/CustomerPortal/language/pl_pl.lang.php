<?php
$mod_strings = array(
	'CustomerPortal'=>'Portal Klienta',
	'LBL_ADVANCED_SETTINGS'=>'Ustawienia zaawansowane',
	'LBL_BASIC_SETTINGS'=>'Ustawienia podstawowe',
	'LBL_DISABLE'=>'Wyłącz',
	'LBL_ENABLE'=>'Włącz',
	'LBL_MODULE'=>'Moduł',
	'LBL_TEMPLATE_DESCRIPTION'=>'Powyższy szablon zostanie zastosowany w mailusubskrybującym portal..',
	'LBL_USER_DESCRIPTION'=>'Powyższy profil użytkownika będzie zarządzał polami, które występują w portalu klienta. Możesz włączyć/wyłączyć pola wyświetlane w portalu klienta.',
	'LBL_VIEW_ALL_RECORD'=>'Wyświetlić wszystkie powiązane rekordy?',
	'Module'=>'Moduł',
	'NO'=>'Nie',
	'SELECT_TEMPLATE'=>'Wybierz szablon',
	'SELECT_USERS'=>'Wybierz użytkowników',
	'Sequence'=>'Sekwencja',
	'Visible'=>'Widoczny',
	'YES'=>'Tak',
);
?>