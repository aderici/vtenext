<?php
$mod_strings = array(
	'LBL_FIELDFORMULAS'=>'Pola formuł',
	'LBL_FIELDFORMULAS_DESCRIPTION'=>'Dodaj równanie spersonalizowane do pól spersonalizowanych',
	'LBL_FIELDS'=>'Pola',
	'LBL_FUNCTIONS'=>'Funkcje',
	'LBL_MODULE_INFO'=>'Formuły zdefiniowanedla',
	'LBL_NEW_FIELD_EXPRESSION_BUTTON'=>'Nowe polefrazy',
	'LBL_SELECT_ONE_DOTDOTDOT'=>'Wybierz jeden…',
	'LBL_SETTINGS'=>'Ustawienia',
	'LBL_TARGET_FIELD'=>'Poledocelowe',
	'LBL_USE_FIELD_VALUE_DASHDASH'=>'Użyj pole wartości',
	'LBL_USE_FUNCTION_DASHDASH'=>'Użyj funkcję',
	'NEED_TO_ADD_A'=>'Musisz dodaćciąg pól lub pole całkowite',
	'FieldFormulas'=>'Pole formuł',
	'LBL_CHECKING'=>'Sprawdzanie…',
	'LBL_CUSTOM_FIELD'=>'Pole spersonalizowane',
	'LBL_DELETE_EXPRESSION_CONFIRM'=>'Czy na pewno chcesz usunąćtę frazę?',
	'LBL_EDIT_EXPRESSION'=>'Edytujfrazę',
	'LBL_EXAMPLES'=>'Przykłady',
	'LBL_EXPRESSION'=>'Frazy',
	'LBL_FIELD'=>'Pole',
);
?>