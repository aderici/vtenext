<?php
$mod_strings = array(
	'Due Date'=>'Data zakończenia',
	'Due Time'=>'Czas zakończenia (godzina:minuty)',
	'End SLA'=>'Koniec SLA',
	'Idle Time Elapsed'=>'Czas miniony w idle',
	'LBL_SLA'=>'Czas SLA',
	'Out SLA Time Elapsed'=>'Czas miniony poza SLA',
	'Reset SLA'=>'Ustaw ponownie SLA',
	'SINGLE_SLA'=>'Zarządzanie SLA',
	'SLA'=>'Zarządzanie SLA',
	'SLA end date'=>'Data zakończenia SLA',
	'SLA Estimated Time'=>'Przewidywany czas SLA',
	'SLA start date'=>'Data początkowa SLA',
	'Time Elapsed'=>'Czas miniony',
	'Time Elapsed Last Status Change'=>'Czas miniony od ostatniej zmiany statusu',
	'Time Last Status Change'=>'Data ostatniej zmiany statusu',
	'Time remaining'=>'Pozostały czas',
	'Update Time'=>'Czas aktualizacji',
);
?>