<?php
$mod_strings = array(
	'FieldFormulas'=>'formules de champs',
	'LBL_FIELDFORMULAS'=>'formules de champs',
	'LBL_FIELDFORMULAS_DESCRIPTION'=>'Ajouter des équations personnalisées aux champs personnalisés',
	'LBL_FIELDS'=>'champs',
	'LBL_FUNCTIONS'=>'fonctions',
	'LBL_FIELD'=>'champ',
	'LBL_EXPRESSION'=>'expression',
	'LBL_SETTINGS'=>'paramètres',
	'LBL_NEW_FIELD_EXPRESSION_BUTTON'=>'nouveau champ d\'expression',
	'LBL_EDIT_EXPRESSION'=>'modifier expression',
	'LBL_MODULE_INFO'=>'formules définies par',
	'NEED_TO_ADD_A'=>'Il est nécessaire d\'ajouter une chaîne ou un champ entier',
	'LBL_CUSTOM_FIELD'=>'champ personnalisé',
	'LBL_CHECKING'=>'vérifier...',
	'LBL_SELECT_ONE_DOTDOTDOT'=>'sélectionnez en un',
	'LBL_TARGET_FIELD'=>'champ objectif',
	'LBL_DELETE_EXPRESSION_CONFIRM'=>'Êtes vous sur de supprimer l\'expression ?',
	'LBL_EXAMPLES'=>'exemples',
	'LBL_USE_FIELD_VALUE_DASHDASH'=>'utiliser le champ valeur',
	'LBL_USE_FUNCTION_DASHDASH'=>'utiliser les fonctions',
);
?>