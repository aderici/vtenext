<?php
$mod_strings = array(
	'Touch'=>'Toucher',
);
?>