<?php
$mod_strings = array(
	'LBL_PRICEBOOK_INFORMATION'=>'informations sur le catalogue',
	'LBL_CUSTOM_INFORMATION'=>'informations personnalisées',
	'LBL_DESCRIPTION_INFORMATION'=>'nom de la description',
	'Price Book Name'=>'nom du catalogue',
	'Product Name'=>'nom du produit',
	'Active'=>'actif',
	'Description'=>'description  ',
	'Created Time'=>'horaire de création',
	'Modified Time'=>'horaire de modification',
	'LBL_LIST_PRODUCT_NAME'=>'nom du produit',
	'LBL_PRODUCT_CODE'=>'numéro de série',
	'LBL_PRODUCT_UNIT_PRICE'=>'prix unitaire',
	'LBL_PB_LIST_PRICE'=>'prix du catalogue',
	'LBL_ACTION'=>'action',
	'PriceBook'=>'catalogue',
	'Currency'=>'devise',
	'PriceBook No'=>'numéro du catalogue',
);
?>