<?php
$mod_strings = array(
	'Assigned To'=>'Assigné à',
	'Created Time'=>'Période de création',
	'Description'=>'Note',
	'LBL_MYNOTES_INFORMATION'=>'Note d\'information',
	'Modified Time'=>'Modifier la période',
	'MyNotes'=>'Remarques',
	'SINGLE_MyNotes'=>'Note',
	'Subject'=>'Titre',
);
?>