<?php
$mod_strings = array(
	'LBL_MODULE_NAME'=>'administration',
	'LBL_MODULE_TITLE'=>'administration : accueil',
	'LBL_NEW_FORM_TITLE'=>'nouvelle entreprise',
	'ERR_DELETE_RECORD'=>'Un numéro d\'enregistrement doit être spécifié pour supprimer la Société `',
);
?>