<?php
$mod_strings = array(
	'LBL_WATERMARK'=>'insérer une valeur pour chercher',
	'LBL_NO_RECORDS'=>'aucun élément trouvé',
);
?>