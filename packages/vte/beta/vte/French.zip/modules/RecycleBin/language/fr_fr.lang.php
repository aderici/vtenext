<?php
$mod_strings = array(
	'MSG_EMPTY_RB_CONFIRMATION'=>'Êtes vous sûr de vouloir supprimer définitivement tous les enregistrements supprimés de la base de données?',
	'LBL_SELECT_MODULE'=>'sélectionner module',
	'RecycleBin'=>'corbeille',
	'LBL_EMPTY_MODULE'=>'Aucun résultat trouvé pour restaurer le module',
	'LBL_MASS_RESTORE'=>'restaurer',
	'LBL_EMPTY_RECYCLEBIN'=>'vider la corbeille',
	'LNK_RESTORE'=>'restaurer',
	'LBL_NO_PERMITTED_MODULES'=>'aucun module consenti disponible',
);
?>