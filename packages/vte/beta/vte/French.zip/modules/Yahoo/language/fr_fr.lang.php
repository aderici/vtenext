<?php
$mod_strings = array(
	'LBL_MODULE_NAME'=>'entreprises',
	'LBL_MODULE_TITLE'=>'entreprise : accueil',
	'LBL_SEARCH_FORM_TITLE'=>'rechercher une entreprise',
	'LBL_LIST_FORM_TITLE'=>'liste des entreprises',
	'LBL_NEW_FORM_TITLE'=>'nom de l\'entreprise',
	'ERR_DELETE_RECORD'=>'un numéro d\'enregistrement doit être inscrit pour supprimer le compte',
);
?>