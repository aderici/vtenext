<?php
$mod_strings = array(
	'LBL_SYSTEM_CONFIG'=>'configurations du système',
);
?>