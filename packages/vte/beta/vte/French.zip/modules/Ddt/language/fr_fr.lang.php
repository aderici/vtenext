<?php
$mod_strings = array(
	'Ddt'=>'ddt',
	'LBL_CUSTOM_INFORMATION'=>'informations personnalisées',
	'LBL_DDT_INFORMATION'=>'informations ddt',
	'LBL_DESCRIPTION_INFORMATION'=>'description des informations',
	'LBL_TERMS_INFORMATION'=>'termes et conditions',
	'SINGLE_Ddt'=>'ddt',
	'Add Invoice'=>'créer facture',
	'Customer No'=>'numéro client',
	'--None--'=>'--aucun--',
	'Ddt No'=>'numéro ddt',
	'Product Name'=>'Nom du produit',
	'Quantity'=>'Quantité',
	'Service Name'=>'Nom du service',
	'Sub Total'=>'Global',
	'Creator'=>'Créateur',
	'LBL_RELATED_PRODUCTS'=>'Détails du produit',
);
?>