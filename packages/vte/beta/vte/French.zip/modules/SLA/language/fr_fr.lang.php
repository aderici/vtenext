<?php
$mod_strings = array(
	'SLA'=>'gestionnaire SLA',
	'SINGLE_SLA'=>'gestionnaire SLA',
	'LBL_SLA'=>'timming SLA',
	'Time Elapsed'=>'temps écoulé',
	'Time remaining'=>'temps restant',
	'SLA start date'=>'date de départ SLA',
	'SLA end date'=>'date de fin SLA',
	'Update Time'=>'horaire de mise à jour',
	'SLA Estimated Time'=>'temps SLA prévu',
	'Due Date'=>'date de fermeture',
	'Due Time'=>'heure de fermeture (hh:mm)',
	'Time Last Status Change'=>'date du dernier changement de statut',
	'Time Elapsed Last Status Change'=>'temps écoulé depuis le dernier changement de statut',
	'Reset SLA'=>'reset SLA',
	'End SLA'=>'fin de la SLA',
	'Idle Time Elapsed'=>'temps écoulé en idle',
	'Out SLA Time Elapsed'=>'temps écoulé en dehors de SLA',
);
?>