<?php
$mod_strings = array(
	'Asterisk'=>'astérisque',
	'LBL_ASTERISK_INFORMATION'=>'information sur les astérisques',
	'Call From'=>'appel de',
	'Call To'=>'appel à  ',
	'Time Of Call'=>'durée de l\'appel',
	'PBXManager ID'=>'PBX ID',
	'PBX Manager'=>'gestionnaire des appels',
	'PBXManager'=>'gestionnaire des appels',
	'SINGLE_PBXManager'=>'gestionnaire des appels',
	'Status'=>'statut',
);
?>