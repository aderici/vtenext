<?php
$mod_strings = array(
	'LBL_BOOKMARKED_URL'=>'marques pages',
	'LBL_MANAGE_BOOKMARKS'=>'gestion des marques pages',
	'LBL_BOOKMARK_LIST'=>'liste des marques pages',
	'LBL_MY_BOOKMARKS'=>'mes marques pages',
	'LBL_NEW_BOOKMARK'=>'nouveau marque page',
	'LBL_BOOKMARK'=>'marque page',
	'LBL_NAME'=>'nom :',
	'LBL_URL'=>'URL :',
	'LBL_ADD'=>'ajouter  ',
	'LBL_SNO'=>'#',
	'LBL_BOOKMARK_NAME_URL'=>'nom et URL du marque page',
	'LBL_TOOLS'=>'instruments',
	'LBL_MANAGE_SITES'=>'gestion des sites',
	'LBL_MY_SITES'=>'sites',
	'LBL_SET_DEFAULT_BUTTON'=>'mettre en place par défaut',
);
?>