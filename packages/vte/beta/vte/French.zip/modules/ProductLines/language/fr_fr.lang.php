<?php
$mod_strings = array(
	'LBL_CUSTOM_INFORMATION'=>'Personnaliser informations',
	'LBL_DESCRIPTION_INFORMATION'=>'Informations Description',
	'LBL_PRODUCTLINES_INFORMATION'=>'Ligne d\'information sur le produit',
	'ProductLineName'=>'Nom ligne',
	'ProductLines'=>'Les lignes de produits',
	'SINGLE_ProductLines'=>'Ligne de produits',
);
?>