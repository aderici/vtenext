<?php
$mod_strings = array(
	'LBL_LOAD_REPORT'=>'Rapport de téléchargement',
	'Targets'=>'cible',
	'SINGLE_Targets'=>'cible',
	'LBL_TARGETS_INFORMATION'=>'informations cible',
	'LBL_CUSTOM_INFORMATION'=>'informations personnalisées',
	'LBL_DESCRIPTION_INFORMATION'=>'informations description',
	'Target Name'=>'nom de la cible',
	'Target No'=>'numéro de la cible',
	'Target Type'=>'type de cible',
	'Target State'=>'statut de la cible',
	'End Time'=>'fermeture de la cible',
	'Assigned To'=>'attribué à',
	'Description'=>'description  ',
	'Created Time'=>'période de création',
	'Modified Time'=>'période de modification',
	'LBL_LOAD_LIST'=>'chercher liste',
	'Select One'=>'sélectionner un  ',
	'Creator'=>'Créateur',
	'Included Targets'=>'Cibles incluses',
	'Parent Targets'=>'Cibles parent',
);
?>