<?php
$mod_strings = array(
	'LBL_MODULE_NAME'=>'entreprise',
	'LBL_MODULE_TITLE'=>'entreprise : accueil',
	'LBL_SEARCH_FORM_TITLE'=>'rechercher entreprise',
	'LBL_LIST_FORM_TITLE'=>'liste des entreprises',
	'LBL_NEW_FORM_TITLE'=>'nouvelle entreprise',
	'ERR_DELETE_RECORD'=>'un numéro d\'enregistrement doit être spécifié pour pouvoir supprimer l\'entreprise',
);
?>