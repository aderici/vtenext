<?php
$mod_strings = array(
	'Actual value'=>'Valeur actuelle',
	'Assigned To'=>'Assigné à',
	'Audit No'=>'Numéro de révision',
	'ChangeLog'=>'Change Log',
	'Created Time'=>'Période de création',
	'Earlier value'=>'Valeur précédente',
	'Field'=>'Domaine',
	'LBL_CHANGELOG_INFORMATION'=>'Informations ChangeLog',
	'LBL_CUSTOM_INFORMATION'=>'Personnaliser informations',
	'LBL_LINKED_TO'=>'Il a été lié à',
	'Modified by'=>'Edité par',
	'Modified fields'=>'Modifications',
	'Modified Time'=>'Modifier la période',
	'Related To'=>'Lié à',
	'SINGLE_ChangeLog'=>'Change Log',
	'LBL_HAS_CHANGED_THE_RECORD'=>'a modifié le dossier',
	'LBL_HAS_CREATED_THE_RECORD'=>'a créé le dossier',
	'LBL_HAS_LINKED_THE_RECORD'=>'a lié %s',
	'LBL_HAS_REMOVED_LINK_WITH_RECORD'=>'a supprimé le lien avec %s',
);
?>