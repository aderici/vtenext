<?php
$mod_strings = array(
	'LBL_UPDATE_PACK_INVALID'=>'Ce package de mise à jour est pas applicable à votre version de TEV. <br /> Contactez CRMVillage.BIZ ou votre partenaire de référence pour la version correcte.',
	'LBL_UPDATE'=>'charger',
	'LBL_UPDATE_DESC'=>'mettre à jour la version',
	'LBL_URL'=>'adresse SVN',
	'LBL_USERNAME'=>'nom de l\'utilisateur',
	'LBL_PASWRD'=>'mot de passe',
	'LBL_SIGN_IN_DETAILS'=>'détails connexion',
	'LBL_SIGN_IN_CHANGE'=>'changer  la connexion',
	'LBL_CURRENT_VERSION'=>'build en cours',
	'LBL_MAX_VERSION'=>'dernier build disponible',
	'LBL_UPDATE_DETAILS'=>'détails de la mise à jour',
	'LBL_UPDATE_BUTTON'=>'mettre à jour   ',
	'LBL_UPDATE_TO'=>'mettre à jour à',
	'LBL_SPECIFIC_VERSION'=>'spécifier version',
	'LBL_SPECIFICIED_VERSION'=>'version spécifiée',
);
?>