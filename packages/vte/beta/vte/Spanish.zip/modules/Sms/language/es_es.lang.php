<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'TITLE_VTIGERCRM_SMS' => 'vtigerCRM Sms',
  'TITLE_COMPOSE_SMS' => 'Compose Sms',
  'LBL_CONF_EXTENSION_ERROR' => 'This file has an invalid format, please use a PDF,TIFFor PS file',
  'LBL_SMSSELECT_INFO' => 'has the following Sms numbers associated. Please Select the Sms number to which the sms should be sent',
  'LBL_NO_RECORDS' => 'No Records Found',
  'LBL_NO_RCPTS_SMS_ERROR' => 'No recipients specified',
  'LBL_CONF_SMSSERVER_ERROR' => 'Please configure your outgoing smsserver under Settings ---> Outgoing Sms Server link',
  'LBL_SMSSELECT_INFO3' => 'You are not authorised to view sms numbers of the selected Record(s).',
  'LBL_PLEASE_ATTACH' => 'Please select a valid file to attach and try again!',
  'LBL_KINDLY_UPLOAD' => 'Please configure <font color="red">upload_tmp_dir</font> variable in php.ini file.',
  'LBL_EXCEED_MAX' => 'Sorry, the uploaded file exceeds the maximum file size. Please try a file smaller than ',
  'LBL_BYTES' => ' bytes',
  'LBL_CHECK_USER_SMSID' => 'Please check the current user\'s sms number.',
  'LBL_TO' => 'To:',
  'LBL_COMPOSE_SMS' => 'Compose Sms',
  'LBL_MODULE_NAME' => 'Sms',
  'LBL_FORWARD_BUTTON' => 'Forward',
  'LBL_LIST_RELATED_TO' => 'Related to',
  'LBL_LIST_DATE' => 'Date Sent',
  'LBL_SUBJECT' => 'Subject:',
  'LBL_DETAILVIEW_SMS' => 'Sms',
  'LBL_COMPOSE' => 'Compose',
  'MESSAGE_SMS_COULD_NOT_BE_SEND' => 'The sms cannot be sent',
  'MESSAGE_PLEASE_CHECK_ASSIGNED_USER_SMSID' => 'Please check the user\'s SMS number.',
  'MESSAGE_PLEASE_CHECK_THE_FROM_SMSID' => 'Please check the sms number of',
  'MESSAGE_SMS_COULD_NOT_BE_SEND_TO_THIS_SMSID' => 'Sms could not be sent to this sms number',
  'MESSAGE_CHECK_SMS_SERVER_NAME' => 'Please Check the Sms Server Name...',
  'MESSAGE_CHECK_SMS_ID' => 'Please Check the Sms Id of "Assigned To" User...',
  'MESSAGE_SMS_HAS_SENT_TO_USERS' => 'Sms has been sent to the following User(s) :',
  'MESSAGE_SMS_HAS_SENT_TO_CONTACTS' => 'Sms has been sent to the following Contact(s) :',
  'MESSAGE_SMS_ID_IS_INCORRECT' => 'Sms number is incorrect. Please Check this Sms number...',
  'MESSAGE_ADD_USER_OR_CONTACT' => 'Please Add any User(s) or Contact(s)...',
  'MESSAGE_SMS_SENT_SUCCESSFULLY' => ' Sms\'s sent successfully!',
  'PLEASE_CHECK_THIS_SMSID' => 'Please check this sms number',
  'EXTERNAL_RECEIVER' => 'external Receiver',
  'Assigned To' => 'Assigned To',
  'Subject' => 'Subject',
  'Attachment' => 'Attachment',
  'Document' => 'Document(s)',
  'MESSAGE_NO_SUBJECT' => 'Subject field is empty. Do you want to continue?',
  'LBL_NO_SUBJECT' => '(no-Subject)',
  'LBL_SMSSELECT_INFO1' => 'The following Sms number types are associated to the selected',
  'LBL_SMSSELECT_INFO2' => 'Select the Sms number types to which, the sms should be sent',
  'LBL_MULTIPLE' => 'Multiple',
  'SELECT_SMS' => 'Select Sms numbers',
  'MESSAGE_PLEASE_CHECK_FROM_THE_SMSID' => 'Please check the sms number of',
  'SINGLE_Sms' => 'Sms',
  'LBL_NO_RCPTS_EMAIL_ERROR' => 'No recipients specified',
  'LBL_CONF_MAILSERVER_ERROR' => 'Please configure your outgoing Sms server under Settings ---> Outgoing Sms Server link',
  'LBL_SMS_INFORMATION' => 'Sms Information',
  'Description' => 'Text',
  'MESSAGE_NO_DESCRIPTION' => 'Please insert the message',
  'LBL_MESSAGE' => 'Message',
  'LBL_CHARACTERS' => 'characters',
);

?>