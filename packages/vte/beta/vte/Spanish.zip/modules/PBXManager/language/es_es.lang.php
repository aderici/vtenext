<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'PBX Manager' => 'PBX Manager',
  'PBXManager' => 'PBX Manager',
  'SINGLE_PBXManager' => 'PBX Manager',
  'Asterisk' => 'Asterisk',
  'LBL_ASTERISK_INFORMATION' => 'Información ASTERISK',
  'Call From' => 'Llamada de',
  'Call To' => 'Llamar a',
  'Time Of Call' => 'Tiempo de Llamada',
  'PBXManager ID' => 'Id PBX Manager',
);

?>
