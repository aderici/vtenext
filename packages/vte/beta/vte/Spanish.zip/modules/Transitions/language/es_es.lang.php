<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'LBL_STATUS_SAVE' => 'Enviar',
  'LBL_STATUS_CANCEL' => 'Retorno',
  'LBL_STATUS_CURRENT_STATUS' => 'Situación actual',
  'LBL_STATUS_CHANGED_USER' => 'Usuario',
  'LBL_STATUS_CHANGED_USER_FROM' => 'cambiado desde',
  'LBL_STATUS_CHANGED_USER_TO' => 'a',
  'LBL_STATUS_CHANGED_USER_ON' => 'en',
  'LBL_STATUS_CHANGED_MOTIVATION' => 'Nota :',
  'LBL_STATUS_HIST_USER' => 'Usuario',
  'LBL_STATUS_HIST_OLD_SALES_STAGE' => 'Condición anterior',
  'LBL_STATUS_HIST_NEW_SALES_STAGE' => 'Estado Siguiente',
  'LBL_STATUS_HIST_MOTIVATION' => 'Motivación',
  'LBL_STATUS_HIST_LAST_MODIFIED' => 'Modif.Date Time',
  'LBL_STATUS_CAN_CHANGE_TO' => 'Cambiar estado a:',
  'LBL_STATUS_CAN_CHANGE_IF_FILL' => 'Para cambiar el estado',
  'LBL_STATUS_NO_AVAILABLE_STATES' => 'Sin estado disponible',
  'LBL_STATUS_MANDATORY_FIELDS' => 'Usted debe llenar',
  'LBL_YOU_ARE_HERE' => '',
  'LBL_NO_DATA' => 'No hay reglas definidas.',
  'LBL_COPY' => 'Copia',
  'LBL_MAKE_TRANSITION' => 'Gestionar',
  'LBL_UNMAKE_TRANSITION' => 'Sin mánager',
  'LBL_MANAGED' => '[Gestionado]',
  'LBL_CANT_SET_FIELD' => 'No se puede establecer múltiples campos de estado!',
  'LBL_STATUS_BLOCK_ACTUAL_STATE' => 'Estado actual',
  'LBL_CURR_ST_FIELD' => 'Campo Estado',
  'LBL_INITIAL_STATE' => 'Estado inicial',
  'LBL_RESET_ALL' => 'Elija ninguno',
  'LBL_SELECT_ALL' => 'Seleccionar todo',
  'LBL_UPDATE' => 'Aplicar',
  'LBL_ST_MANAGER' => 'Administrador de estado',
  'LBL_ST_MANAGER_DESCRIPTION' => 'Habilitar transiciones de estado/Desactivar',
  'LBL_ASSIGNABLE' => 'Utilice para "Asignado a"',
  'Transitions History' => 'Historial de estado',
  'HEADER_ID' => 'id',
  'HEADER_OLD_STATUS' => 'estado de edad',
  'HEADER_NEW_STATUS' => 'nuevo estatus',
  'HEADER_USER' => 'usuario',
  'HEADER_NOTE' => 'nota',
  'HEADER_DATE' => 'fecha',
  'Transitions' => 'Administrador de estado',
  'COPY_FROM' => 'Copiar desde',
);

?>