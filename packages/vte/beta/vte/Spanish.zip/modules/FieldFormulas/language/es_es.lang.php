<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'FieldFormulas' => 'Campos calculados',
  'LBL_FIELDFORMULAS' => 'Campos calculados',
  'LBL_FIELDFORMULAS_DESCRIPTION' => 'Añadir ecuaciones a campos personalizados',
  'LBL_FIELDS' => 'Campos',
  'LBL_FUNCTIONS' => 'Funciones',
  'LBL_FIELD' => 'Campo',
  'LBL_EXPRESSION' => 'Expresión',
  'LBL_SETTINGS' => 'Configuración',
  'LBL_NEW_FIELD_EXPRESSION_BUTTON' => 'Nueva Expresión de Campo',
  'LBL_EDIT_EXPRESSION' => 'Editar Expresión',
  'LBL_MODULE_INFO' => 'Fórmulas definidas para',
  'NEED_TO_ADD_A' => 'Tienes que añadir un tipo cadena o entero ',
  'LBL_CUSTOM_FIELD' => 'Campo personalizado',
  'LBL_CHECKING' => 'Comprobando...',
  'LBL_SELECT_ONE_DOTDOTDOT' => 'Selecciona Uno...',
  'LBL_TARGET_FIELD' => 'Campo objetivo',
  'LBL_DELETE_EXPRESSION_CONFIRM' => '¿Seguro que quieres eliminar esta expresión?',
  'LBL_EXAMPLES' => 'Ejemplos',
  'LBL_USE_FIELD_VALUE_DASHDASH' => '-- Utilizar Valor de Campo --',
  'LBL_USE_FUNCTION_DASHDASH' => '-- Utilizar Función --',
);

?>
