<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'LBL_ASSIGN_BUTTON' => 'Asignar',
  'ADD_PICKLIST_VALUES' => 'Añadir valores de lista de selección',
  'LBL_EXISTING_PICKLIST_VALUES' => 'Existente valores de lista de selección',
  'LBL_PICKLIST_ADDINFO' => 'Añadir nuevas entradas aquí',
  'LBL_SELECT_ROLES' => 'Seleccione papeles',
  'LBL_NON_EDITABLE_PICKLIST_ENTRIES' => 'Los valores no editables',
  'EDIT_PICKLIST_VALUE' => 'Edición de los valores de lista de selección',
  'LBL_EDIT_HERE' => 'Reemplazar con: ',
  'LBL_SELECT_TO_EDIT' => 'Seleccione un valor para editar: ',
  'DELETE_PICKLIST_VALUES' => 'Eliminar los valores de lista de selección',
  'LBL_REPLACE_WITH' => 'Reemplazar con: ',
  'ASSIGN_PICKLIST_VALUES' => 'Asignar valores de lista de selección',
  'LBL_PICKLIST_VALUES' => 'Los valores de lista de selección disponibles',
  'LBL_PICKLIST_VALUES_ASSIGNED_TO' => 'Los valores de lista de selección para la Asignación ',
  'LBL_ADD_TO_OTHER_ROLES' => 'Agregar a otros roles',
  'LBL_OK_BUTTON_LABEL' => 'Okay',
  'LBL_DISPLAYED_VALUES' => 'Todos los valores accesibles para el papel se muestran a continuación',
  'LBL_ADD_VALUE' => 'Agregar valor',
  'Code' => 'Código',
  'LBL_EMPTY' => 'No hay entradas',
  'LBL_ERROR_GENERIC' => 'Error de operación',
  'LBL_SUCCESS' => 'La operación se realizó con éxito',
  'LBL_CODE_NOT_UNIQUE' => 'El código no es único, por favor, inserte una diferente',
  'LBL_MANDATORY' => 'Los campos marcados con (*) son obligatorios',
);

?>