<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'SLA' => 'SLA Management',
  'SINGLE_SLA' => 'SLA Management',
  'LBL_SLA' => 'SLA timings',
  'Time Elapsed' => 'Time Elapsed',
  'Time remaining' => 'Time remaining',
  'SLA start date' => 'SLA start date',
  'SLA end date' => 'SLA end date',
  'Update Time' => 'Update Time',
  'SLA Estimated Time' => 'SLA Estimated Time',
  'Due Date' => 'Due Date',
  'Due Time' => 'Due time (hh:mm)',
  'Time Last Status Change' => 'Time Last Status Change',
  'Time Elapsed Last Status Change' => 'Time Elapsed since Last Status Change',
  'Reset SLA' => 'Reset SLA',
  'End SLA' => 'End SLA',
  'Idle Time Elapsed' => 'Idle Time Elapsed',
  'Out SLA Time Elapsed' => 'Out SLA Time Elapsed',
);

?>