<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'Ddt' => 'Albaranes',
  'LBL_CUSTOM_INFORMATION' => 'Información personalizada',
  'LBL_DDT_INFORMATION' => 'Nota de entrega Información',
  'LBL_DESCRIPTION_INFORMATION' => 'Descripción Información',
  'LBL_TERMS_INFORMATION' => 'Términos y condiciones',
  'SINGLE_Ddt' => 'Nota de entrega',
  'Add Invoice' => 'Añadir factura',
  'Customer No' => 'Cliente No',
  '--None--' => '--Ninguno--',
  'Ddt No' => 'Nota de entrega No',
  'Product Name' => 'Nombre del producto',
  'Service Name' => 'Nombre del servicio',
  'Quantity' => 'Cantidad',
  'Data Ddt' => 'Nota de entrega Fecha',
  'Causale' => 'Razón',
  'Trasporto' => 'Carro',
  'Condizione di Consegna' => 'Plazo de Entrega',
  'Conto deposito' => 'Cuenta de depósitos',
  'Reso da conto deposito' => 'Las mercancías de retorno enviadas por cuenta de depósitos',
  'Conto lavorazione' => 'Fines de fabricación',
  'Reso da conto lavorazione' => 'Las mercancías de retorno se ha enviado con fines de fabricación',
  'Prestito d uso' => 'Préstamo para el uso',
  'Reso da prestito d uso' => 'Las mercancías de retorno enviados por préstamo',
  'Conto riparazione' => 'Devuelto para reparación',
  'Reso da conto riparazione' => 'Las mercancías de retorno enviado a reparación',
  'Conto manutenzione' => 'Servicio de mantenimiento',
  'Reso da conto manutenzione' => 'Las mercancías de retorno enviados para mantenimiento',
  'Conto visione' => 'Evaluación gratuita',
  'Reso da conto visione' => 'Las mercancías de retorno enviados para su evaluación',
  'Omaggio' => 'Libre',
  'Campionario' => 'Caso de la muestra',
  'Vendita' => 'Comercio',
  'Porto franco' => 'Transporte gratuito',
  'Porto assegnato' => 'Portes',
  'Franco magazzino venditore' => 'Ex-Works almacén del vendedor',
  'Franco magazzino compratore' => 'Ex-Works almacén del comprador',
  'Sub Total' => 'Total',
);

?>