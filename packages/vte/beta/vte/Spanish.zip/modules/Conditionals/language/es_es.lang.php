<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'LBL_CREATE_NEW_CONDITIONAL' => 'Crear nueva matriz condicional',
  'FpofvFieldid' => 'Campo ID',
  'FpofvFieldlabel' => 'Nombre del campo',
  'FpovReadPermission' => 'Leer',
  'FpovWritePermission' => 'Escribir',
  'FpovMandatoryPermission' => 'Obli.',
  'FpofvChkFieldLabel' => 'El campo para comprobar',
  'FpofvCondition' => 'Condición',
  'FpofvChkFieldValue' => 'Valor',
  'FpofvChkRoleGroup' => 'Regla usuario',
  'LBL_NEW_FPOFV_BUTTON_LABEL' => 'Nueva regla',
  'LBL_NEW_FPOFV_BUTTON_TITLE' => 'Nueva regla',
  'LBL_NEW_FPOFV_BUTTON_KEY' => '',
  'LBL_CRITERIA_VALUE_LESS_EQUAL' => 'Menor o igual a igual (<=)',
  'LBL_CRITERIA_VALUE_LESS_THAN' => 'Menos que (<)',
  'LBL_CRITERIA_VALUE_MORE_EQUAL' => 'Más o igual a (>=)',
  'LBL_CRITERIA_VALUE_MORE_THAN' => 'Más que (>)',
  'LBL_CRITERIA_VALUE_EQUAL' => 'Equivale (=)',
  'LBL_CRITERIA_VALUE_NOT_EQUAL' => 'No es igual a  (!=)',
  'LBL_CRITERIA_VALUE_INCLUDES' => 'incluye',
  'LBL_FPOFV_CONTITIONS_LIST' => 'Lista de reglas',
  'LBL_FPOFV_RULE_NAME' => 'Nombre de la regla',
  'LBL_FPOFV_MODULE_NAME' => '1. Elija módulo',
  'LBL_FPOFV_CRITERIA_NAME' => '2. Criterios',
  'LBL_FPOFV_FIELD_NAME' => '3. Elija Condiciones',
  'LBL_FPOFV_ACTION_NAME' => '4. El campo de gestionar',
  'LBL_FPOFV_EXTENDED_PARAMETERS' => '5. Permisos de campo',
  'LBL_FPOFV_READ_PERMISSION' => 'Puede leer',
  'LBL_FPOFV_WRITE_PERMISSION' => 'Se puede escribir',
  'LBL_FPOFV_MANDATORY_PERMISSION' => 'Obligatorio',
  'LBL_ROLES' => 'Roles',
  'LBL_ROLES_SUBORDINATES' => 'Roles y subordinados',
  'LBL_GROUP' => 'Grupo',
  'LBL_FPOFV_MANAGE_PERMISSION' => 'Gestionado',
  'LBL_ST_SHOW' => 'Show',
  'LBL_ST_RESET' => 'Reajustar',
  'NO_CONDITIONS' => '--no hay condiciones--',
  'ADD_RULES' => 'Agregar condición',
  'LBL_ACTION' => 'Acción',
  'Conditionals' => 'Condicionales',
);

?>