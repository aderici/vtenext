<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'TITLE_VTIGERCRM_FAX' => 'VTEDDY Fax',
  'TITLE_COMPOSE_FAX' => 'Redactar Fax',
  'LBL_CONF_EXTENSION_ERROR' => 'Este archivo tiene un formato no válido, por favor, utilice un archivo PDF, TIFF o archivo PS',
  'LBL_FAXSELECT_INFO' => 'tiene los siguientes números de fax asociados Éntrenos Seleccione los números de fax al que se debe enviar el fax',
  'LBL_NO_RECORDS' => 'No se encontraron registros',
  'LBL_NO_RCPTS_FAX_ERROR' => 'No hay destinatarios especificados',
  'LBL_CONF_FAXSERVER_ERROR' => 'Por favor, configure su servidor de fax saliente en Configuración ---> enlace de faxes Envío de servidor',
  'LBL_FAXSELECT_INFO3' => 'Usted no está autorizado para ver los números de fax del Registro (s) seleccionado.',
  'LBL_PLEASE_ATTACH' => 'Por favor, seleccione un archivo válido para unir y vuelva a intentarlo!',
  'LBL_KINDLY_UPLOAD' => 'Por favor, configure <font color = "red"> upload_tmp_dir </ font> variable en el archivo php.ini.',
  'LBL_EXCEED_MAX' => 'Lo sentimos, el archivo subido excede el tamaño máximo de archivo. Por favor, pruebe con un archivo más pequeño que ',
  'LBL_BYTES' => ' bytes',
  'LBL_CHECK_USER_FAXID' => 'Por favor, compruebe el número de fax del usuario actual.',
  'LBL_TO' => 'A:',
  'LBL_COMPOSE_FAX' => 'Redactar Fax',
  'LBL_MODULE_NAME' => 'Fax',
  'LBL_FORWARD_BUTTON' => 'Adelante',
  'LBL_LIST_RELATED_TO' => 'Relacionado con',
  'LBL_LIST_DATE' => 'Fecha de envío',
  'LBL_SUBJECT' => 'Sujeto:',
  'LBL_DETAILVIEW_FAX' => 'Fax',
  'LBL_COMPOSE' => 'Componer',
  'MESSAGE_FAX_COULD_NOT_BE_SEND' => 'Fax No se pudo enviar al usuario asignado.',
  'MESSAGE_PLEASE_CHECK_ASSIGNED_USER_FAXID' => 'Por favor, compruebe el número de fax del usuario',
  'MESSAGE_PLEASE_CHECK_THE_FROM_FAXID' => 'Por favor, compruebe el número de fax de',
  'MESSAGE_FAX_COULD_NOT_BE_SEND_TO_THIS_FAXID' => 'Fax No se pudo enviar al número de fax',
  'MESSAGE_CHECK_FAX_SERVER_NAME' => 'Compruebe el nombre del servidor de fax ...',
  'MESSAGE_CHECK_FAX_ID' => 'Por favor, marque el fax Id de "Asignado a" Usuario ...',
  'MESSAGE_FAX_HAS_SENT_TO_USERS' => 'Fax ha sido enviada a la siguiente Usuario(s):',
  'MESSAGE_FAX_HAS_SENT_TO_CONTACTS' => 'Fax ha sido enviada a la siguiente Contacto(s):',
  'MESSAGE_FAX_ID_IS_INCORRECT' => 'El número de fax es incorrecto. Por favor, compruebe el número de',
  'MESSAGE_ADD_USER_OR_CONTACT' => 'Por favor agregue cualquier usuario(s) o de contacto(s) ...',
  'MESSAGE_FAX_SENT_SUCCESSFULLY' => ' Los faxes enviados con éxito!',
  'PLEASE_CHECK_THIS_FAXID' => 'Por favor, consulte este número de fax.',
  'EXTERNAL_RECEIVER' => 'receptor externo',
  'LBL_FAXSELECT_INFO1' => 'Los siguientes tipos de números de fax están asociados a la seleccionada',
  'LBL_FAXSELECT_INFO2' => 'Seleccione los tipos de número de fax al que, se debe enviar el fax',
  'LBL_MULTIPLE' => 'Múltiple',
  'SELECT_FAX' => 'Seleccione los números de fax',
  'Assigned To' => 'Asignado a',
  'Subject' => 'Sujeto',
  'Attachment' => 'Accesorio',
  'Document' => 'Documento(s)',
  'MESSAGE_NO_SUBJECT' => 'Asunto campo está vacío. ¿Quieres continuar?',
  'LBL_NO_SUBJECT' => '(sin asunto)',
  'SINGLE_fax' => 'Fax',
  'LBL_NO_RCPTS_EMAIL_ERROR' => 'No hay destinatarios especificados',
  'LBL_CONF_MAILSERVER_ERROR' => 'Por favor, configure su servidor de fax saliente en Configuración ---> enlace de faxes Envío de servidor',
);

?>