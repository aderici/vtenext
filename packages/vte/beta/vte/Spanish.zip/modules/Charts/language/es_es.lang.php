<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'Charts' => 'Gráficas',
  'SINGLE_Charts' => 'Tabla',
  'LBL_CHARTS_INFORMATION' => 'Información Gráfico',
  'LBL_CUSTOM_INFORMATION' => 'Información personalizada',
  'LBL_DESCRIPTION_INFORMATION' => 'Descripción Información',
  'Chart Name' => 'Nombre del diagrama',
  'Report' => 'Informe',
  'Folder Name' => 'Nombre de carpeta',
  'Chart Type' => 'Tipo de gráfico',
  'Chart Legend' => 'Mostrar leyenda',
  'Chart Labels' => 'Mostrar etiquetas',
  'Chart Values' => 'Mostrar valores',
  'Chart Exploded' => 'Rebanadas despieces',
  'Chart Order' => 'Orden de los datos',
  'Chart Level' => 'Nivel Reportar',
  'Chart Merge' => 'Combinar pequeñas rebanadas',
  'Chart Palette' => 'Paleta',
  'Chart Formula' => 'Fórmula',
  'BarVertical' => 'Las barras verticales',
  'BarHorizontal' => 'Las barras horizontales',
  'Line' => 'Línea',
  'Pie' => 'Pastel',
  'Ring' => 'Anillo',
  'Pie3D' => '3D Pastel',
  'Ring3D' => '3D Anillo',
  'Split' => 'Separación/División',
  'Level1' => 'Primer nivel',
  'Level2' => 'Segundo nivel',
  'Level3' => 'Tercer nivel',
  'OrderNone' => 'Ninguno',
  'OrderAsc' => 'Ascendente',
  'OrderDesc' => 'Descendente',
  'ChartValuesNone' => 'Ninguno',
  'ChartValuesRaw' => 'Valores',
  'ChartValuesPercent' => 'Porcentaje',
  'default' => 'Defecto',
  'bw' => 'Blanco y Negro',
  'grey16' => 'Gris',
  'bluered16' => 'Azul y Rojo',
  'redyellow16' => 'Rojo y Amarillo',
  'LBL_EMPTY_LABEL' => '[vacío]',
  'LBL_OTHERS_LABEL' => '[otros]',
  'LBL_PARTIAL_DATA' => 'Datos parciales',
  'LBL_CREATE_CHART' => 'Crear tabla',
  'LBL_CHART_PREVIEW' => 'Preestreno',
  'LBL_REPORT_NO_SUMMARY' => 'Crear un resumen en el informe',
  'LBL_UPDATED_TO' => 'Actualizado',
  'LBL_SIZE' => 'Tamaño',
  'COUNT' => 'Contar',
  'SUM' => 'Suma',
  'AVG' => 'Promedio',
  'MIN' => 'Mínimo',
  'MAX' => 'Máximo',
);

?>