<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'LBL_MODCOMMENTS_INFORMATION' => 'Información de Comentario',
  'LBL_OTHER_INFORMATION' => 'Información Adicional',
  'LBL_CUSTOM_INFORMATION' => 'Información Personalizada',
  'Assigned To' => 'Asignado a',
  'Created Time' => 'Fecha Creación',
  'Modified Time' => 'Fecha Modificación',
  'Related To' => 'Relacionado con',
  'Creator' => 'Creador',
  'Related To Comments' => 'Palabras de los Padres',
  'LBL_ADD_COMMENT' => 'Añadir Comentario',
  'LBL_AUTHOR' => 'Autor',
  'LBL_ON' => 'en',
  'LBL_MINE' => 'Mio',
  'LBL_LAST5' => 'Ultimos 5',
  'LBL_MODCOMMENTS_COMMUNICATIONS' => 'Negociaciones',
  'ModComments' => 'Comentarios',
  'Comments' => 'Comentarios',
  'SINGLE_ModComments' => 'Comentario',
  'Comment' => 'Comentario',
  'LBL_DEFAULT_REPLY_TEXT' => 'Responder',
  'LBL_MODCOMMENTS_REPLIES' => 'Respuestas',
  'LBL_MODCOMMENTS_REPLY' => 'Responder',
  'LBL_PUBLISH' => 'Publicar a',
  'LBL_SHOW_ALL_REPLIES_1' => 'Mostrar todos los',
  'LBL_SHOW_ALL_REPLIES_2' => 'respuestas',
  'LBL_AGO' => '%s hace',
  'lbl_second' => 'segundo',
  'lbl_seconds' => 'segundos',
  'lbl_minute' => 'minuto',
  'lbl_minutes' => 'acta',
  'lbl_hour' => 'hora',
  'lbl_hours' => 'horas',
  'lbl_day' => 'día',
  'lbl_days' => 'días',
  'lbl_week' => 'semana',
  'lbl_weeks' => 'semanas',
  'lbl_month' => 'mes',
  'lbl_months' => 'meses',
  'lbl_year' => 'año',
  'lbl_years' => 'años',
  'lbl_decade' => 'década',
  'lbl_decades' => 'décadas',
  'lbl_now' => 'ahora',
  'LBL_CROP_AVATAR' => 'Recortar la imagen de usuario',
  'LBL_CROP' => 'Cosecha',
  'LBL_PLEASE_SELECT_REGION' => 'Por favor seleccione una parte de la imagen',
  'LBL_SAVE_AVATAR' => '¿Quieres guardar esta avatar?',
  'Visibility' => 'Visibilidad',
  'All' => 'todos',
  'LBL_TO' => 'a',
  'LBL_ABOUT' => 'acerca de',
  'LBL_SHOW_OTHER_TALKS' => 'Mostrar otras conversaciones',
  'ModComments ID' => 'Id Comentario',
  'LBL_SHOW_FULL_COMMENT'=>'Otro',
);

?>
