<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'LBL_PRICEBOOK_INFORMATION' => 'Información de Tarifa:',
  'LBL_CUSTOM_INFORMATION' => 'Información Personalizada',
  'LBL_DESCRIPTION_INFORMATION' => 'Nombre:',
  'Price Book Name' => 'Nombre de Tarifa',
  'Product Name' => 'Nombre de Producto',
  'Active' => 'Activo',
  'Description' => 'Descripción',
  'Created Time' => 'Creado',
  'Modified Time' => 'Modificado',
  'LBL_LIST_PRODUCT_NAME' => 'Nombre de Producto',
  'LBL_PRODUCT_CODE' => 'Código de Producto',
  'LBL_PRODUCT_UNIT_PRICE' => 'Precio Unitario',
  'LBL_PB_LIST_PRICE' => 'Lista de Precios',
  'LBL_ACTION' => 'Acción',
  'PriceBook' => 'Tarifa',
  'Currency' => 'Moneda',
  'PriceBook No' => 'Nº Tarifa',
);

?>
