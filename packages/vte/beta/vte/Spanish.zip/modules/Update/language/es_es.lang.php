<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

global $enterprise_mode;
$mod_strings = array (
  'LBL_UPDATE' => 'Actualización',
  'LBL_UPDATE_DESC' => 'Actualización de la versión',
  'LBL_URL' => 'Dirección SVN',
  'LBL_USERNAME' => 'Usuario',
  'LBL_PASWRD' => 'Password',
  'LBL_SIGN_IN_DETAILS' => 'Datos de acceso',
  'LBL_SIGN_IN_CHANGE' => 'Cambio de inicio de sesión',
  'LBL_CURRENT_VERSION' => 'Build actual',
  'LBL_MAX_VERSION' => 'Última generación disponible',
  'LBL_UPDATE_DETAILS' => 'Detalles de la actualización',
  'LBL_UPDATE_BUTTON' => 'Actualización',
  'LBL_UPDATE_TO' => 'Actualizar para',
  'LBL_SPECIFIC_VERSION' => 'Especifique versión',
  'LBL_SPECIFICIED_VERSION' => 'Versión especificada',
  'LBL_UPDATE_PACK_INVALID' => "Esta actualización no es compatible con su $enterprise_mode versión.<br />Por favor, póngase en contacto con CRMVillage.BIZ o su socio para la versión correcta.",
);

?>