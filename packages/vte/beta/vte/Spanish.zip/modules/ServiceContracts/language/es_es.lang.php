<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'Service Contracts' => 'Contratos de Servicio',
  'ServiceContracts' => 'Contratos de Servicio',
  'SINGLE_ServiceContracts' => 'Contrato de Servicio',
  'LBL_SERVICE_CONTRACT_INFORMATION' => 'Información Contrato de Servicio',
  'LBL_CUSTOM_INFORMATION' => 'Información Personalizada',
  'Contract No' => 'Número Contrato',
  'Assigned To' => 'Asignado a',
  'Created Time' => 'Fecha creación',
  'Modified Time' => 'Fecha modificación',
  'Start Date' => 'Fecha inicio',
  'Due date' => 'Fecha vencimiento',
  'End Date' => 'Fecha fin',
  'Related to' => 'Relacionado con',
  'Tracking Unit' => 'Unidad de seguimiento',
  'Total Units' => 'Total Unidades',
  'Used Units' => 'Unidades consumidas',
  'Subject' => 'Referencia',
  'Progress' => 'Progreso',
  'Type' => 'Tipo',
  'Planned Duration' => 'Duración estimada (días)',
  'Actual Duration' => 'Duración real (días)',
  'Status' => 'Estado',
  'Priority' => 'Prioridad',
  'Undefined' => 'Indefinido',
  'In Planning' => 'Planificado',
  'In Progress' => 'En progreso',
  'On Hold' => 'En espera',
  'Complete' => 'Completado',
  'Archived' => 'Archivado',
  'Support' => 'Soporte',
  'Services' => 'Servicios',
  'Service' => 'Service',
  'Administrative' => 'Administrativo',
  'Low' => 'Baja',
  'Normal' => 'Normal',
  'High' => 'Alta',
  'None' => 'Ninguno',
  'Hours' => 'Horas',
  'Days' => 'Días',
  'Incidents' => 'Incidentes',
  'LBL_MODULE_NAME' => 'Contratos de Servicio',
  'Residual Units' => 'Residual Units',
  'Service Requests' => 'Peticiones de Servicio',
  'ServiceContracts ID' => 'Id Contrato Servicio',
);

?>
