<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'Timecards' => 'Timecards',
  'LBL_DESCRIPTION_INFORMATION' => 'Description Information',
  'LBL_CUSTOM_INFORMATION' => 'Custom Information',
  'LBL_TIMECARD_INFORMATION' => 'Timecard Information',
  'LBL_TICKET_INFORMATION' => 'Ticket Information',
  'SINGLE_Timecards' => 'Timecard',
  'TCDate' => 'Date',
  'TCWorker' => 'User',
  'TCUnits' => 'Units',
  'TCTime' => 'Time <i>(hh:mm)</i>',
  'Product' => 'Product',
  'Description' => 'Description',
  'TCType' => 'Type',
  'Comment' => 'Comment',
  'InvoiceLine' => 'Invoice Line',
  'BlockedComment' => 'Blocked Comment',
  'NewTC' => 'New Timecard',
  'sortorder' => 'Sort Order',
  'NewState' => 'Change ticket status to',
  'ReassignTicketTo' => 'Assign ticket to',
  'LBL_CHANGE' => 'Change Owner',
  'Maintain' => 'Maintain',
  'LBL_ViewTC' => 'View Timecards',
  'Product Name' => 'Product Name',
  'LBL_TCMoveUp' => 'Move Up',
  'LBL_TCMoveDown' => 'Move Down',
  'LBL_CONVERT_AS_SALESORDER_BUTTON_TITLE' => 'Convert to Sales Order',
  'LBL_CONVERT_AS_SALESORDER_BUTTON_KEY' => 'S',
  'LBL_CONVERT_AS_SALESORDER_BUTTON_LABEL' => 'Convert to Sales Order',
  'LBL_PDF_WITH_COMMENTS' => 'Ticket with Comments',
  'LBL_PDF_WITHOUT_COMMENTS' => 'Ticket without Comments',
  'LBL_HelpDesk_Receipt' => 'WorkSheet',
  'MSG_NoSalesEntity' => 'Not Associated',
  'ElapsedTime' => 'Elapsed Time',
  'FinishDate' => 'End date',
  'TimeDedicated' => 'Time Dedicated',
  'WorkMaterial' => 'Work and Material',
  'LBL_Days' => 'Days',
  'sortReturn' => 'Back',
  'sortReturnKey' => 'V',
  'sortClose' => 'Close',
  'sortCloseKey' => 'X',
  'sortReport' => 'Report',
  'sortReportKey' => 'L',
  'sortSeeWO' => 'View Work orders',
  'sortSeeWOKey' => 'V',
  'sortUserNotDefined' => 'User not defined',
  'sortWO' => 'Sort Workorders',
  'sortWOforUser' => 'Sort Workorders for user ',
  'sortNoWOPending' => 'No Workorders pending',
  'sortPendingWO' => 'Pending Workorders for user ',
  'sortOrder' => 'Order',
  'sortTitle' => 'Title',
  'sortMaterial' => 'Material',
  'Err_NoAccountContact' => 'Cannot convert because the ticket is not related to a Contact/Account',
  'Err_ContactWithoutAccount' => 'Cannot convert because the ticket is related to a Contact that is not linked to an account',
  'Created Time' => 'Time created',
  'Modified Time' => 'Modified Time',
  'Type' => 'type',
);

?>