<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'Targets' => 'Blancos',
  'SINGLE_Targets' => 'Objetivo',
  'LBL_TARGETS_INFORMATION' => 'Información Target',
  'LBL_CUSTOM_INFORMATION' => 'Información personalizada',
  'LBL_DESCRIPTION_INFORMATION' => 'Descripción Información',
  'Target Name' => 'Nombre de destino',
  'Target No' => 'Objetivo No',
  'Target Type' => 'Objetivo Type',
  'Target State' => 'Objetivo State',
  'End Time' => 'Hora de finalización',
  'Assigned To' => 'Asignado a',
  'Description' => 'Descripción',
  'Created Time' => 'Creado Tiempo',
  'Modified Time' => 'Hora de modificación',
  'LBL_LOAD_LIST' => 'Cargar lista',
  'LBL_LOAD_REPORT' => 'Informe de carga',
  'Select One' => 'Seleccionar Uno',
);

?>