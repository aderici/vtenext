<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'ChangeLog' => 'Cambio de registro',
  'SINGLE_ChangeLog' => 'Cambio de registro',
  'LBL_CHANGELOG_INFORMATION' => 'Cambio de registro información',
  'LBL_CUSTOM_INFORMATION' => 'Información personalizada',
  'Audit No' => 'Auditoría No',
  'Assigned To' => 'Asignado a',
  'Created Time' => 'Tiempo creado',
  'Modified Time' => 'Hora de modificación',
  'Related To' => 'Relacionado a',
  'Modified fields' => 'Cambios',
  'Modified by' => 'Modificado por',
  'Field' => 'Campo',
  'Earlier value' => 'A principios de valor',
  'Actual value' => 'Valor real',
  'LBL_LINKED_TO' => 'se ha relacionado con',
);

?>