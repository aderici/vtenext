<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'LBL_BOOKMARKED_URL' => 'Marcadores Favoritos',
  'LBL_MANAGE_BOOKMARKS' => 'Administrar Marcadores',
  'LBL_BOOKMARK_LIST' => 'Lista de Favoritos',
  'LBL_MY_BOOKMARKS' => 'Mis Favoritos',
  'LBL_NEW_BOOKMARK' => 'Nuevo Favorito',
  'LBL_BOOKMARK' => 'Favorito',
  'LBL_NAME' => 'Nombre :',
  'LBL_URL' => 'URL :',
  'LBL_ADD' => 'Agregar',
  'LBL_SNO' => '#',
  'LBL_BOOKMARK_NAME_URL' => 'Nombre de Favorito',
  'LBL_TOOLS' => 'Herramientas',
  'LBL_MANAGE_SITES' => 'Gestionar Sitios',
  'LBL_MY_SITES' => 'Mis Sitios',
  'LBL_SET_DEFAULT_BUTTON' => 'Establecer como Predeterminado',
);

?>
