<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Recursos',
  'SINGLE_Assets' => 'Recurso',
  'LBL_ASSET_INFORMATION' => 'Información Recurso',
  'LBL_CUSTOM_INFORMATION' => 'Información Personalizada',
  'LBL_DESCRIPTION_INFORMATION' => 'Notas',
  'Assets' => 'Recursos',
  'Asset Name' => 'Nombre Recurso',
  'Customer Name' => 'Instalado en',
  'Product Name' => 'Producto',
  'Serial Number' => 'Número serie',
  'Asset No' => 'Número recurso',
  'Date Sold' => 'Fecha venta',
  'Date in Service' => 'Fecha instalación',
  'Status' => 'Estado',
  'Shipping Method' => 'Forma de envío',
  'Shipping Tracking Number' => 'Número seguimiento envío',
  'Tag Number' => 'Etiquetado',
  'Notes' => 'Notas',
  'Invoice Name' => 'Ref. Factura',
  'In Service' => 'En Servicio',
  'Out-of-service' => 'Fuera de servicio',
  'Assets ID' => 'Id Recurso',
);

?>