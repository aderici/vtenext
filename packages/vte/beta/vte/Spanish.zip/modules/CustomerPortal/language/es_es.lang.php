<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'CustomerPortal' => 'Portal Cliente',
  'LBL_BASIC_SETTINGS' => 'Configuración Básica',
  'LBL_ADVANCED_SETTINGS' => 'Configuración Avanzada',
  'LBL_MODULE' => 'Módulo',
  'LBL_VIEW_ALL_RECORD' => '¿Mostrar todos los registros relacionados?',
  'YES' => 'Yes',
  'NO' => 'No',
  'LBL_USER_DESCRIPTION' => 'NOTA : El perfil del usuario seleccionado arriba controlará qué campos aparecen en el Portal de Cliente.',
  'SELECT_USERS' => 'Select the Users',
  'LBL_DISABLE' => 'Deshabilitar',
  'LBL_ENABLE' => 'Habilitar',
  'Module' => 'Module',
  'Sequence' => 'Sequence',
  'Visible' => 'Visible',
  'SELECT_TEMPLATE' => 'Select the Template',
  'LBL_TEMPLATE_DESCRIPTION' => 'The above selected template will be used to send the mail of subscription to the portal.',
  'LBL_CUSTOMERPORTAL_SETTINGS' => 'Configuración Portal',
  'LBL_MODULE_INFORMATION' => 'Información Módulo',
  'LBL_USER_INFORMATION' => 'Información Usuario',
  'LBL_YES' => 'Sí',
  'LBL_NO' => 'No',
  'LBL_GROUP_DESCRIPTION' => 'NOTA : Las incidencias se asignarán al usuario/grupo por defecto seleccionado.',
  'LBL_SELECT_USERS' => 'Perfil Usuarios',
  'LBL_DEFAULT_USERS' => 'Asignado por defecto',
  'LBL_SEQUENCE' => 'Secuencia',
  'LBL_VISIBLE' => 'Visible',
);

?>
