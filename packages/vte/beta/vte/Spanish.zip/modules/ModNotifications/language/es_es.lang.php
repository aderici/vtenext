<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'ModNotifications' => 'Notificaciones',
  'SINGLE_ModNotifications' => 'Notificación',
  'LBL_MODNOTIFICATION_INFORMATION' => 'Información de Notificación',
  'LBL_CUSTOM_INFORMATION' => 'Información personalizada',
  'LBL_DESCRIPTION_INFORMATION' => 'Descripción de la información:',
  'Notification No' => 'Notificación No',
  'Assigned To' => 'Asignado a',
  'Created Time' => 'Tiempo creado',
  'Modified Time' => 'Hora de modificación',
  'Related To' => 'Relacionado a',
  'Description' => 'Descripción',
  'Type' => 'Tipo',
  'Creator' => 'Creador',
  'Seen' => 'Visto',
  'LBL_FOLLOW' => 'Notifiqueme de cambios',
  'LBL_NOTIFICATION_MODULE_SETTINGS' => 'Configuración de notificaciones',
  'LBL_CREATE_NOTIFICATION' => 'Notificar a la creación',
  'LBL_EDIT_NOTIFICATION' => 'Notificar al cambio',
  'LBL_SHOW_OTHER_NOTIFICATIONS' => 'Mostrar otras notificaciones',
  'has changed' => 'ha cambiado',
  'has created and assigned to you' => 'ha creado y asignado a usted',
  'Subject' => 'Sujeto',
  'From Email' => 'Mail remitente',
  'From Email Name' => 'Nombre del remitente',
  'responded to' => 'respondido a',
  'has created' => 'ha creado',
  'MSG_STOCK_LEVEL' => 'nivel de stock es bajo',
  'has invited you to' => 'te ha invitado a',
  'will attend' => 'asistirán',
  'did not attend' => 'no asistió',
  'reminder activity' => 'actividad Recordatorio',
  'has related' => 'ha relacionado',
  'MSG_DEAR' => 'querido',
  'MSG_DETAILS_OF' => 'Los detalles de',
  'MSG_DETAILS_ARE' => 'es:',
  'MSG_OTHER_INFO' => 'Haga clic aquí para más detalles',
  'MSG_1_NOTIFICATION_UNSEEN' => 'usted tiene una notificación sin leer',
  'MSG_NOTIFICATIONS_UNSEEN' => 'tienes %s notificaciones no leídas',
  'unseen' => 'no leído',
  'Sent Summary Notification' => 'Enviado Notificación Resumen',
  'Has been changed' => 'Se ha cambiado la vista',
  'LBL_DETAILS' => 'Detalles',
  'has changed your invitation to' => 'ha cambiado y necesita tu participación a',
  'Import Completed' => 'Importación completada para',
  'LBL_INVITATION_QUESTION' => 'Está usted asistiendo',
  'LBL_INVITATION_YES' => 'Participar',
  'LBL_INVITATION_NO' => 'Disminución',
  'LBL_SET_ALL_AS_READ' => 'Marcar todos como leídos',
);

?>