<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Hitos',
  'LBL_MODULE_TITLE' => 'Hitos',
  'LBL_NEW_OPERATION' => 'Nuevo Hito',
  'LBL_MILESTONES' => 'Hitos',
  'LBL_MILESTONE' => 'Hito',
  'Project Milestone ID' => 'ID Hito',
  'projectmilestones' => 'Hitos',
  'ProjectMilestone' => 'Hitos',
  'SINGLE_ProjectMilestone' => 'Hito',
  'LBL_CUSTOM_INFORMATION' => 'Información Personalizada',
  'LBL_PROJECT_MILESTONE_INFORMATION' => 'Información Hito',
  'LBL_DESCRIPTION_INFORMATION' => 'Descripción',
  'Assigned To' => 'Asignado a',
  'Milestone Date' => 'Fecha Hito',
  'Milestone' => 'Hito',
  'Type' => 'Tipo',
  'Related Project' => 'Proyecto relacionado',
  'Related To' => 'Relacionado con',
  'projectid' => 'Relacionado con',
  'administrative' => 'administrativo',
  'operative' => 'operativo',
  'other' => 'otro',
  'Created Time' => 'Fecha Creación',
  'Modified Time' => 'Fecha Modificación',
  'description' => 'Descripción',
  'Description' => 'Descripción',
  'Project Milestone Name' => 'Nombre Hito',
  'Project Milestone No' => 'Nº Hito',
  'Project Milestones' => 'Project Milestones',
  '--none--' => '--ninguno--',
  'ProjectMilestone ID' => 'Id Hito',
);

?>
