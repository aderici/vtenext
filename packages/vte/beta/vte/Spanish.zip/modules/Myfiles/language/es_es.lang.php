<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'Myfiles' => 'Mis archivos',
  'SINGLE_Myfiles' => 'Mi archivo',
  'LBL_MODULEBLOCK_INFORMATION' => 'Información del módulo',
  'LBL_CUSTOM_INFORMATION' => 'Información personalizada',
  'LBL_DESCRIPTION_INFORMATION' => 'Descripción Información',
  'Myfiles No' => 'Mi archivo No',
  'Title' => 'Título',
  'Assigned To' => 'Asignado a',
  'Created Time' => 'Creado Tiempo',
  'Modified Time' => 'Hora de modificación',
  'Folder' => 'Carpeta',
  'LBL_FOLDER_NAME' => 'Nombre de carpeta',
  'LBL_DOWNLOAD_TYPE' => 'Tipo de descarga',
  'LBL_INTERNAL' => 'Interna',
  'LBL_EXTERNAL' => 'Externo',
  'LBL_EXTERNAL_FILE_NAME' => 'Nombre del archivo',
  'LBL_FILE_LOCATION' => 'Ubicación del archivo',
  'Download Type' => 'Tipo de descarga',
  'Version' => 'Versión',
  'Active' => 'Activo',
  'Download Count' => 'Conteo de la descarga',
  'File Name' => 'Nombre del archivo',
  'File Type' => 'Tipo de archivo',
  'File Size' => 'Tamaño',
  'LBL_VIEW_FOLDER' => 'Carpetas',
  'LBL_VIEW_ICON' => 'Iconos',
  'LBL_VIEW_LIST' => 'Lista',
  'LBL_CLICK_DRAG_UPLOAD' => 'Haga clic o arrastre uno o más archivos para cargar',
  'LBL_CLICK_CREATE_FOLDER' => 'Haga clic aquí para crear una carpeta',
  'LBL_FILE_INFORMATION' => 'Información del archivo',
  'LBL_EXTENSION ' => 'Extensión',
  'LBL_CONVERT_OK_MSG' => 'Presentar documento convertido con éxito! Para acceder al documento, haga clic recién creado en el enlace de abajo. Utilice el botón Cerrar para actualizar la lista de archivos de la carpeta.',
  'LBL_CONVERT' => 'Convertir al documento',
  'LBL_CONVERT_TO_DOCUMENT' => 'Conversión de documentos',
  'LBL_RENAME_FILE' => 'Renombrar/Reemplazar archivo',
  'LBL_FILE_NAME' => 'Nombre del archivo',
  'LBL_EXTENSION' => 'Extensión',
  'LBL_FILE_RENAME' => 'Rebautizar',
  'LBL_FILE_REPLACE' => 'Reemplazar',
  'LBL_FILE_JUMP' => 'Saltar',
  'LBL_FILE_RENAME_MSG' => 'Uno más archivos ya están presentes dentro de la carpeta, hacen que quieres hacer?',
  'LBL_FILE_RENAME_HELP' => 'Crear un nuevo archivo con el nuevo nombre elegido',
  'LBL_FILE_REPLACE_HELP' => 'Reemplace el archivo antiguo por uno nuevo',
  'LBL_FILE_JUMP_HELP' => 'No guarde el archivo nuevo',
  'LBL_CONVERT_OK_MSG1' => 'Presentar documento convertido con éxito!',
  'LBL_CONVERT_OK_MSG2' => 'Para acceder al documento, haga clic recién creado en el enlace de abajo.',
  'LBL_CONVERT_OK_MSG3' => 'Utilice el botón Cerrar para actualizar la lista de archivos de la carpeta.',
  'LBL_TITLE_NOT_EMPTY' => 'Llene un título',
  'LBL_ERROR_CONVERT_DOCUMENT' => 'Error documento conversión',
);

?>