<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

$mod_strings = array (
  'Visitreport' => 'Informe de Visita',
  'ModuleFieldLabel' => 'ModuleFieldLabel texto',
  'visitreportname' => 'Nombre visita',
  'Visitreport Name' => 'Nombre visita',
  'LBL_CUSTOM_INFORMATION' => 'Información personalizada',
  'LBL_VISITREPORT_INFORMATION' => 'Visita información',
  'LBL_DESCRIPTION_INFORMATION' => 'Gastos',
  'LBL_SCOPO_INFORMATION' => 'Motivo de la visita',
  'LBL_RESULT_INFORMATION' => 'Resultado de la Visita',
  'Description' => 'Descripción',
  'Created Time' => 'Tiempo creado',
  'Modified Time' => 'Hora de modificación',
  'accountid' => 'Cuenta',
  'kmpercorsi' => 'Km cubierto',
  'spautostr' => 'Costos Highway',
  'spvitoall' => 'Comida y alojamiento costes',
  'spother' => 'Otros costes',
  'scopovisit' => 'Visita Propósito',
  'visitdate' => 'Fecha de visita',
  'visitnote' => 'Visita Nota',
  'ourproduct' => 'El interés en nuestros productos',
  'descspother' => 'Descripción de otros costos',
  'Visitreport No' => 'Informe de Visita No',
  'LBL_ADD_EVENT' => 'Añadir Evento',
  'LBL_ADD_TASK' => 'Agregar tarea',
  'Conoscenza' => 'Contacto',
  'Presentazione' => 'Presentación',
  'Prodotti' => 'Productos',
  'Consegna' => 'Entrega',
  'Offerta' => 'Oferta',
  'Ritiro offerta' => 'Oferta Retiro',
  'Consulenza' => 'Asesoramiento',
  'Voci di capitolato' => 'Items de protocolo',
  'Analisi scientifiche' => 'El análisis científico',
  'Campioni' => 'Muestras',
  'Altro' => 'Otro',
  'Consegna Offerta' => 'Entrega oferta',
  'Presentazione Prodotti' => 'Presentación de productos',
  'Stesura capitolato' => 'La elaboración de las especificaciones',
  'Controllo avanzamento' => 'Control de Progreso',
  'Related To' => 'Relacionado a',
);

?>