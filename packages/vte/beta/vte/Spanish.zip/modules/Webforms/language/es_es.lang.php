<?php
/*+*************************************************************************************
* The contents of this file are subject to the VTECRM License Agreement
* ("licenza.txt"); You may not use this file except in compliance with the License
* The Original Code is: VTECRM
* The Initial Developer of the Original Code is VTECRM LTD.
* Portions created by VTECRM LTD are Copyright (C) VTECRM LTD.
* All Rights Reserved.
***************************************************************************************/

global $enterprise_mode;
$mod_strings = array (
  'Webform' => 'Webform',
  'Webforms' => 'Formulario Web',
  'LBL_SUCCESS' => "ha sido añadido a $enterprise_mode CRM.",
  'LBL_FAILURE' => "No se ha podido añadir la entrada en $enterprise_mode CRM.",
  'LBL_ERROR_CODE' => 'Código Error',
  'LBL_ERROR_MESSAGE' => 'Mensaje Error',
  'LBL_WEBFORM_NAME' => 'Nombre Formulario',
  'LBL_DESCRIPTION' => 'Descripción',
  'LBL_MODULE' => 'Módulo',
  'LBL_RETURNURL' => 'URL retorno',
  'LBL_ACTION' => 'Acción',
  'LBL_ASSIGNED_TO' => 'Asignado a',
  'LBL_EDIT' => 'Editar',
  'LBL_DELETE' => 'Eliminar',
  'LBL_SOURCE' => 'Mostrar Formulario',
  'LBL_MODULE_INFORMATION' => 'Información Formulario',
  'LBL_FIELD_INFORMATION' => 'Información Campos',
  'LBL_ENABLE' => 'Habilitar',
  'LBL_ENABLED' => 'Habilitado',
  'LBL_FIELDLABEL' => 'Nombre Campo',
  'LBL_DEFAULT_VALUE' => 'Imponer Valor',
  'LBL_NEUTRALIZEDFIELD' => 'Campo Referencia Formulario',
  'LBL_PUBLICID' => 'Id Público',
  'LBL_NO_WEBFORM' => 'No se han encontrado Formularios Web!',
  'LBL_CREATE_WEBFORM' => 'Crear un Formulario Web',
  'LBL_POSTURL' => 'URL destino',
  'LBL_REQUIRED' => 'Requerido',
  'LBL_STATUS' => 'Estado',
  'LBL_EMBED_MSG' => 'Copia el siguiente formulario en tu página web',
  'LBL_CANCEL' => 'Cancelar',
  'LBL_SAVE' => 'Guardar',
  'LBL_SELECT_VALUE' => '--Selecciona Valor--',
  'LBL_DUPLICATE_NAME' => 'Un formulario con ese nombre ya existe',
  'ERR_CREATE_WEBFORM' => 'No se ha podido crear el formulario',
  'LBL_SELECT_USER' => 'Selecciona Usuario',
  'LBL_HIDDEN' => 'Oculto',
);

?>
