<?php
$mod_strings = array(
	'LBL_WATERMARK'=>'Вставьте значение для поиска..',
	'LBL_NO_RECORDS'=>'Никакие найденные записи',
);
?>