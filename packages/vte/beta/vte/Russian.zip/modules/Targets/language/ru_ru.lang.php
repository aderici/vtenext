<?php
$mod_strings = array(
	'Targets'=>'Цели',
	'SINGLE_Targets'=>'Цель',
	'LBL_TARGETS_INFORMATION'=>'Целевая информация',
	'LBL_CUSTOM_INFORMATION'=>'Пользовательская информация',
	'LBL_DESCRIPTION_INFORMATION'=>'Информация об описании',
	'Target Name'=>'Целевое имя',
	'Target No'=>'Предназначайтесь нет',
	'Target Type'=>'Целевой тип',
	'Target State'=>'Целевое состояние',
	'End Time'=>'Время окончания',
	'Assigned To'=>'Присвоенный',
	'Description'=>'Описание',
	'Modified Time'=>'Время изменено',
	'LBL_LOAD_LIST'=>'Список загрузки',
	'LBL_LOAD_REPORT'=>'Отчет загрузки',
	'Select One'=>'Выберите One',
	'Creator'=>'Создатель',
	'Created Time'=>'Период создания',
);
?>