<?php
$mod_strings = array(
	'WSAPP'=>'WSAPP',
);
?>