<?php
$mod_strings = array(
	'LBL_BASIC_SETTINGS'=>'Основные настройки',
	'LBL_ADVANCED_SETTINGS'=>'Расширенные настройки',
	'LBL_MODULE'=>'Модуль CRM',
	'LBL_VIEW_ALL_RECORD'=>'Просмотреть все связанные записи?',
	'YES'=>'да',
	'NO'=>'Нет',
	'LBL_USER_DESCRIPTION'=>'',
	'SELECT_USERS'=>'Выберите пользователей',
	'LBL_DISABLE'=>'Отключить',
	'LBL_ENABLE'=>'Включить',
	'Module'=>'Модуль',
	'Sequence'=>'Последовательность',
	'Visible'=>'Видимый',
	'SELECT_TEMPLATE'=>'Выберите шаблон PDF',
	'LBL_TEMPLATE_DESCRIPTION'=>'Вышеупомянутый выбранный шаблон будет использоваться для отправки почты подписки к порталу.',
	'CustomerPortal'=>'Клиентский Портал',
);
?>