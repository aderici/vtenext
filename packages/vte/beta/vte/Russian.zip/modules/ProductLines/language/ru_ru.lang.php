<?php
$mod_strings = array(
	'ProductLines'=>'Производственные линии',
	'SINGLE_ProductLines'=>'Производственная линия',
	'LBL_PRODUCTLINES_INFORMATION'=>'Информация о производственной линии',
	'LBL_CUSTOM_INFORMATION'=>'Пользовательская информация',
	'LBL_DESCRIPTION_INFORMATION'=>'Информация об описании',
	'ProductLineName'=>'Имя строки',
);
?>