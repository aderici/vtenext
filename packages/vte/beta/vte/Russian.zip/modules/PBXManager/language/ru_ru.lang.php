<?php
$mod_strings = array(
	'Asterisk'=>'Asterisk',
	'Time Of Call'=>'Продолжительность звонка',
	'PBX Manager'=>'Менеджер по PBX',
	'PBXManager'=>'Менеджер по PBX',
	'SINGLE_PBXManager'=>'Менеджер по PBX',
	'LBL_ASTERISK_INFORMATION'=>'Информация о ASTERISK',
	'Call From'=>'Звонок от',
	'Call To'=>'Звонок в',
	'Status'=>'Статус',
);
?>