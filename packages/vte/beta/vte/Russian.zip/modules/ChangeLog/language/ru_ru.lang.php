<?php
$mod_strings = array(
	'ChangeLog'=>'Журнал изменений',
	'SINGLE_ChangeLog'=>'Журнал изменений',
	'LBL_CHANGELOG_INFORMATION'=>'Информация о журнале изменений',
	'LBL_CUSTOM_INFORMATION'=>'Пользовательская информация',
	'Assigned To'=>'Присвоенный',
	'Modified Time'=>'Время изменено',
	'Related To'=>'Связанный с',
	'Modified fields'=>'Изменения',
	'Modified by'=>'Измененный',
	'Field'=>'Поле',
	'Actual value'=>'Фактическое значение',
	'LBL_LINKED_TO'=>'был соединен с',
	'LBL_HAS_CHANGED_THE_RECORD'=>'изменил запись',
	'LBL_HAS_CREATED_THE_RECORD'=>'создал запись',
	'LBL_HAS_LINKED_THE_RECORD'=>'соединил %s',
	'LBL_HAS_REMOVED_LINK_WITH_RECORD'=>'удалил ссылку с %s',
	'Created Time'=>'Период создания',
	'Earlier value'=>'Предыдущее значение',
	'Audit No'=>'Номер редакции',
);
?>