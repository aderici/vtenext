<?php
$mod_strings = array(
	'FieldFormulas'=>'Полевые формулы',
	'LBL_FIELDFORMULAS'=>'Полевые формулы',
	'LBL_FIELDFORMULAS_DESCRIPTION'=>'Добавьте пользовательские уравнения к пользовательским полям',
	'LBL_FIELDS'=>'Поля',
	'LBL_FUNCTIONS'=>'Функции',
	'LBL_FIELD'=>'Поле',
	'LBL_EXPRESSION'=>'Выражение',
	'LBL_SETTINGS'=>'Настройки',
	'LBL_NEW_FIELD_EXPRESSION_BUTTON'=>'Новое полевое выражение',
	'LBL_EDIT_EXPRESSION'=>'Выражение редактирования',
	'LBL_MODULE_INFO'=>'Формулы, определенные для ',
	'NEED_TO_ADD_A'=>'Необходимо добавить строковый или целый тип ',
	'LBL_CUSTOM_FIELD'=>'Пользовательское поле',
	'LBL_CHECKING'=>'Проверка...',
	'LBL_SELECT_ONE_DOTDOTDOT'=>'Выберите One...',
	'LBL_TARGET_FIELD'=>'Целевое поле',
	'LBL_DELETE_EXPRESSION_CONFIRM'=>'Вы уверены, что хотите удалить выражение?',
	'LBL_EXAMPLES'=>'Примеры',
	'LBL_USE_FIELD_VALUE_DASHDASH'=>'- Используйте значение поля-',
	'LBL_USE_FUNCTION_DASHDASH'=>'- Используйте функцию-',
);
?>