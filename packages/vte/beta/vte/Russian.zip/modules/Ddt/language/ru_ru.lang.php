<?php
$mod_strings = array(
	'Ddt'=>'Накладные',
	'LBL_CUSTOM_INFORMATION'=>'Пользовательская информация',
	'LBL_DDT_INFORMATION'=>'Информация о накладной',
	'LBL_DESCRIPTION_INFORMATION'=>'Информация об описании',
	'LBL_TERMS_INFORMATION'=>'Условия',
	'LBL_RELATED_PRODUCTS'=>'Особенности продукта',
	'SINGLE_Ddt'=>'Накладная',
	'Add Invoice'=>'Добавьте счет',
	'--None--'=>'Ничего--',
	'Product Name'=>'Название продукта',
	'Service Name'=>'Сервисное название',
	'Quantity'=>'Количество',
	'Sub Total'=>'Общее количество',
	'Creator'=>'Создатель',
	'Customer No'=>'Номер Клиента',
	'Ddt No'=>'Номер накладной',
);
?>