<?php
$mod_strings = array(
	'MyNotes'=>'Примечания',
	'SINGLE_MyNotes'=>'Примечание:',
	'LBL_MYNOTES_INFORMATION'=>'Отметьте информацию',
	'Subject'=>'Предмет',
	'Description'=>'Описание',
	'Assigned To'=>'Присвоенный',
	'Modified Time'=>'Время изменено',
	'Created Time'=>'Период создания',
);
?>