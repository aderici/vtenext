<?php
$mod_strings = array(
	'RecycleBin'=>'Корзина',
	'MSG_EMPTY_RB_CONFIRMATION'=>'Вы уверены, Вы хотите Постоянно удалить все удаленные записи из своей базы данных?',
	'LBL_SELECT_MODULE'=>'Выберите Module',
	'LBL_EMPTY_MODULE'=>'Никакие записи, которые, как находят, Восстановили в модуле',
	'LBL_MASS_RESTORE'=>'Восстановление',
	'LBL_EMPTY_RECYCLEBIN'=>'Пустая корзина',
	'LNK_RESTORE'=>'восстановление',
	'LBL_NO_PERMITTED_MODULES'=>'Никакие санкционированные доступные модули',
);
?>