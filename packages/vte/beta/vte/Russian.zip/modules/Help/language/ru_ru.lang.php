<?php
$mod_strings = array(
	'LBL_MODULE_NAME'=>'Учетные записи',
	'LBL_MODULE_TITLE'=>'Учетные записи:Главная страница',
	'LBL_SEARCH_FORM_TITLE'=>'Поиск учетной записи',
	'LBL_LIST_FORM_TITLE'=>'Список учетной записи',
	'LBL_NEW_FORM_TITLE'=>'Новая учетная запись',
	'ERR_DELETE_RECORD'=>'Выберите рекордное число для удаления vtiger_account.',
);
?>