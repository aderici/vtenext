<?php
$mod_strings = array(
	'LBL_MY_SITES'=>'Сайты',
	'LBL_SET_DEFAULT_BUTTON'=>'Набор как значение по умолчанию',
	'LBL_BOOKMARKED_URL'=>'BookMarked URL\'s',
	'LBL_MANAGE_BOOKMARKS'=>'Управляйте закладками',
	'LBL_BOOKMARK_LIST'=>'Список закладок',
	'LBL_MY_BOOKMARKS'=>'Мои закладки',
	'LBL_NEW_BOOKMARK'=>'Новая закладка',
	'LBL_BOOKMARK'=>'Закладка',
	'LBL_NAME'=>'Тема:',
	'LBL_URL'=>'URL',
	'LBL_ADD'=>'Добавьте событие',
	'LBL_SNO'=>'#',
	'LBL_BOOKMARK_NAME_URL'=>'Закладка Name & URL',
	'LBL_TOOLS'=>'Инструменты',
	'LBL_MANAGE_SITES'=>'Управляйте сайтами',
);
?>