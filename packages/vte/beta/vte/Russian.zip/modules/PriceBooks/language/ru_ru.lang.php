<?php
$mod_strings = array(
	'LBL_PRICEBOOK_INFORMATION'=>'Информация о каталоге цен:',
	'LBL_CUSTOM_INFORMATION'=>'Пользовательская информация',
	'LBL_DESCRIPTION_INFORMATION'=>'Информация об описании',
	'Price Book Name'=>'Название каталога цен',
	'Product Name'=>'Название продукта',
	'Active'=>'Активный',
	'Description'=>'Описание',
	'Created Time'=>'Время создано',
	'Modified Time'=>'Время изменено',
	'LBL_LIST_PRODUCT_NAME'=>'Название продукта',
	'LBL_PRODUCT_CODE'=>'Номер детали',
	'LBL_PRODUCT_UNIT_PRICE'=>'Цена за единицу товара',
	'LBL_PB_LIST_PRICE'=>'Объявленная рыночная цена',
	'LBL_ACTION'=>'Действия',
	'PriceBook'=>'Каталог цен',
	'Currency'=>'Валюта',
	'PriceBook No'=>'PriceBook нет',
);
?>