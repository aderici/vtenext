<?php
$mod_strings = array(
	'Time Elapsed Last Status Change'=>'Время с Последнего Изменения Статуса истекло',
	'Time Last Status Change'=>'Время последнего изменение статуса',
	'Time remaining'=>'Оставшееся время',
	'Due Date'=>'Дата закрытия',
	'Due Time'=>'Время закрытия (час:мин)',
	'SLA'=>'Управление SLA',
	'SINGLE_SLA'=>'Управление SLA',
	'LBL_SLA'=>'Синхронизации SLA',
	'SLA start date'=>'Дата начала SLA',
	'SLA end date'=>'Дата окончания SLA',
	'Update Time'=>'Время обновления',
	'SLA Estimated Time'=>'SLA предполагаемое время',
	'Reset SLA'=>'Сбросьте SLA',
	'End SLA'=>'Конец SLA',
	'Idle Time Elapsed'=>'Время простоя протекло',
	'Out SLA Time Elapsed'=>'Время SLA протекло',
	'Time Elapsed'=>'Время истекло',
);
?>