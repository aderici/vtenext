<?php
$mod_strings = array(
	'LBL_ASSIGN_BUTTON'=>'Присвоиться',
	'LBL_EXISTING_PICKLIST_VALUES'=>'Существующие значения picklist',
	'LBL_PICKLIST_ADDINFO'=>'Добавьте новые записи здесь',
	'LBL_NON_EDITABLE_PICKLIST_ENTRIES'=>'Не доступные для редактирования записи Picklist',
	'EDIT_PICKLIST_VALUE'=>'Отредактируйте значения picklist',
	'LBL_EDIT_HERE'=>'Замена: ',
	'LBL_SELECT_TO_EDIT'=>'Выберите значение для редактирования: ',
	'LBL_REPLACE_WITH'=>'Замена: ',
	'LBL_PICKLIST_VALUES'=>'Доступные значения picklist',
	'LBL_PICKLIST_VALUES_ASSIGNED_TO'=>'Присвоенный picklist оценивает за ',
	'LBL_ADD_TO_OTHER_ROLES'=>'Добавьте к другим ролям',
	'LBL_OK_BUTTON_LABEL'=>'Хорошо',
	'LBL_SELECT_ROLES'=>'Выберите роли',
	'LBL_DISPLAYED_VALUES'=>'Все доступные значения для роли показывают ниже',
	'ADD_PICKLIST_VALUES'=>'Добавьте значения списка выбора',
	'ASSIGN_PICKLIST_VALUES'=>'Присвойте значения списка выбора',
	'DELETE_PICKLIST_VALUES'=>'Удалите значения списка выбора',
);
?>