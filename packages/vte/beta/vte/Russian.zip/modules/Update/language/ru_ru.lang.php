<?php
$mod_strings = array(
	'LBL_UPDATE'=>'Обновление',
	'LBL_UPDATE_DESC'=>'Версия обновления',
	'LBL_URL'=>'URL',
	'LBL_USERNAME'=>'Имя пользователя:',
	'LBL_PASWRD'=>'Пароль',
	'LBL_SIGN_IN_DETAILS'=>'Данные для входа в систему',
	'LBL_SIGN_IN_CHANGE'=>'Вход в систему изменения',
	'LBL_CURRENT_VERSION'=>'Текущая сборка',
	'LBL_MAX_VERSION'=>'Последняя доступная сборка',
	'LBL_UPDATE_DETAILS'=>'Детали обновления',
	'LBL_UPDATE_BUTTON'=>'Обновление',
	'LBL_UPDATE_TO'=>'Обновление',
	'LBL_SPECIFIC_VERSION'=>'Определите версию',
	'LBL_SPECIFICIED_VERSION'=>'Указанная версия',
	'LBL_UPDATE_PACK_INVALID'=>'Это обновление не поддерживается Вашей версией VTE. <br/> свяжитесь с CRMVillage.BIZ или Вашим Партнером для правильной версии.',
);
?>