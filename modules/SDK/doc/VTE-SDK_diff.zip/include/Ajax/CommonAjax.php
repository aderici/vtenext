<?php
/*********************************************************************************
 ** The contents of this file are subject to the vtiger CRM Public License Version 1.0
  * ("License"); You may not use this file except in compliance with the License
  * The Original Code is:  vtiger CRM Open Source
  * The Initial Developer of the Original Code is vtiger.
  * Portions created by vtiger are Copyright (C) vtiger.
  * All Rights Reserved.
  *
  ********************************************************************************/
//crmv@sdk-25183
$sdk_file = SDK::getFile($_REQUEST['module'],$_REQUEST['file']);
if ($sdk_file == '') {
	$sdk_file = $_REQUEST['file'];
}
checkFileAccess('modules/'.$_REQUEST['module'].'/'.$sdk_file.'.php');
require_once('modules/'.$_REQUEST['module'].'/'.$sdk_file.'.php');
//crmv@sdk-25183e
?>