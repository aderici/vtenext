<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
require_once('Smarty_setup.php');
require_once("data/Tracker.php");
require_once('include/logging.php');
require_once('include/ListView/ListView.php');
require_once('include/database/PearDatabase.php');
require_once('include/ComboUtil.php');
require_once('include/utils/utils.php');
global $app_strings,$app_list_strings; //DS-CR VlMe 10.4.2008 - add $app_list_strings 
global $currentModule;
global $theme;
$url_string = '';
$smarty = new vtigerCRM_Smarty;
if (!isset($where)) $where = "";

if(isset($_REQUEST['parenttab']) && $_REQUEST['parenttab']){
$parent_tab=$_REQUEST['parenttab'];
$smarty->assign("CATEGORY",$parent_tab);}

$url = '';
$popuptype = '';
$popuptype = $_REQUEST["popuptype"];

//added to get relatedto field value for todo, while selecting from the popup list, after done the alphabet or basic search.
if(isset($_REQUEST['maintab']) && $_REQUEST['maintab'] != '')
{
        $act_tab = $_REQUEST['maintab'];
        $url = "&maintab=".$act_tab;
}
$smarty->assign("MAINTAB",$act_tab);

switch($currentModule)
{
	case 'Contacts':
		$focus = CRMEntity::getInstance($currentModule);
		$log = LoggerManager::getLogger('contact_list');
		$smarty->assign("SINGLE_MOD",'Contact');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		else
			$smarty->assign("RETURN_MODULE",'Emails');
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','lastname','true','basic',$popuptype,"","",$url);
		break;
	case 'Campaigns':
		$focus = CRMEntity::getInstance($currentModule);
		$log = LoggerManager::getLogger('campaign_list');
		$smarty->assign("SINGLE_MOD",'Campaign');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','campaignname','true','basic',$popuptype,"","",$url);
		break;
	case 'Accounts':
		$focus = CRMEntity::getInstance($currentModule);
		$log = LoggerManager::getLogger('account_list');
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		$smarty->assign("SINGLE_MOD",'Account');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		else
			$smarty->assign("RETURN_MODULE",'Emails');
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','accountname','true','basic',$popuptype,"","",$url);
		break;
	case 'Leads':
		$focus = CRMEntity::getInstance($currentModule);
		$log = LoggerManager::getLogger('contact_list');
		$smarty->assign("SINGLE_MOD",'Lead');
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		else
			$smarty->assign("RETURN_MODULE",'Emails');
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','lastname','true','basic',$popuptype,"","",$url);
		break;
	case 'Potentials':
		$focus = CRMEntity::getInstance($currentModule);
		$log = LoggerManager::getLogger('potential_list');
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		$smarty->assign("SINGLE_MOD",'Opportunity');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','potentialname','true','basic',$popuptype,"","",$url);
		break;
	case 'Quotes':
		$focus = CRMEntity::getInstance($currentModule);
		$log = LoggerManager::getLogger('quotes_list');
		$smarty->assign("SINGLE_MOD",'Quote');
		//crmv@14492
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);	
		//crmv@14492 end			
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','subject','true','basic',$popuptype,"","",$url);
		break;
	case 'Invoice':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'Invoice');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','subject','true','basic',$popuptype,"","",$url);
		break;
	case 'Products':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'Product');
		if(isset($_REQUEST['curr_row']))
		{
			$curr_row = $_REQUEST['curr_row'];
			$smarty->assign("CURR_ROW", $curr_row);
			$url_string .="&curr_row=".$_REQUEST['curr_row'];
		}
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');	
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','productname','true','basic',$popuptype,"","",$url);
		break;
	case 'Vendors':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'Vendor');
		//denis - senza le related dei fornitori non lasciano selezionare nulla
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		//denis e
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');//crmv@22366
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','vendorname','true','basic',$popuptype,"","",$url);
		break;
	case 'SalesOrder':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'SalesOrder');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','subject','true','basic',$popuptype,"","",$url);
		break;
	case 'PurchaseOrder':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'PurchaseOrder');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','subject','true','basic',$popuptype,"","",$url);
		break;
	case 'PriceBooks':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'PriceBook');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		if(isset($_REQUEST['fldname']) && $_REQUEST['fldname'] !='')
		{
			$smarty->assign("FIELDNAME",$_REQUEST['fldname']);
			$url_string .="&fldname=".$_REQUEST['fldname'];
		}
		if(isset($_REQUEST['productid']) && $_REQUEST['productid'] !='')
		{
			$smarty->assign("PRODUCTID",$_REQUEST['productid']);
			$url_string .="&productid=".$_REQUEST['productid'];
		}
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','bookname','true','basic',$popuptype,"","",$url);
		break;
	case 'Users':
		require_once("modules/$currentModule/Users.php");
		$focus = new Users();
		$smarty->assign("SINGLE_MOD",'Users');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','user_name','true','basic',$popuptype,"","",$url);
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		break;
	case 'HelpDesk':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'HelpDesk');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
		$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		//ds@8 project management tool
		$smarty->assign("ADD_TO_URL","&file=".$_REQUEST['file']);
		$smarty->assign("file",$_REQUEST['file']);
		//ds@8e
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','ticket_title','true','basic',$popuptype,"","",$url);
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		break;
	case 'Documents':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'Note');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",vtlib_purify($_REQUEST['return_module']));
		else
			$smarty->assign("RETURN_MODULE",'Emails');
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','notes_title','true','basic',$popuptype,"","",$url);
		break;		
	//ds@28 workflow	
	case 'Workflow':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'Workflow');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
		$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','phrase','true','basic',$popuptype,"","","");
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		break;
	//ds@28e
	//ds@8 project management tool
	//crmv@15310	
	case 'Projects':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'Projects');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
		$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		$smarty->assign("FORM",$_REQUEST['form']);
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','project_name','true','basic',$popuptype,"","","");
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
	break;
	//crmv@15310 end
	//ds@8
	//ds@26
	case 'Visitreport':
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD",'Visitreport');
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
		$smarty->assign("RETURN_MODULE",$_REQUEST['return_module']);
		$alphabetical = AlphabeticalSearch($currentModule,'Popup','crmid','true','basic',$popuptype,"","","");
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
	break;
	//ds@26e
	// Special case handling (for curr_row value) for Services module
	case 'Services':
		if(isset($_REQUEST['curr_row']))
		{
			$curr_row = vtlib_purify($_REQUEST['curr_row']);
			$smarty->assign("CURR_ROW", $curr_row);
			$url_string .="&curr_row=".vtlib_purify($_REQUEST['curr_row']);
		}	
	// vtlib customization: Generic hook for Popup selection
	default:
		$focus = CRMEntity::getInstance($currentModule);
		$smarty->assign("SINGLE_MOD", $currentModule);		
		if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] !='')
			$smarty->assign("RETURN_MODULE",vtlib_purify($_REQUEST['return_module']));
		$alphabetical = AlphabeticalSearch($currentModule,'Popup',$focus->def_basicsearch_col,'true','basic',$popuptype,"","",$url);	//crmv@21249
		if (isset($_REQUEST['select'])) $smarty->assign("SELECT",'enable');
		break;
	// END	
}
// vtlib customization: Initialize focus to get generic popup
if($_REQUEST['form'] == 'vtlibPopupView') {
	vtlib_setup_modulevars($currentModule, $focus);
}
// END
$smarty->assign("RETURN_ACTION",$_REQUEST['return_action']);


$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";
$smarty->assign("MOD", $mod_strings);
$smarty->assign("APP", $app_strings);
$smarty->assign("APPLIST", $app_list_strings["moduleList"]); //DS-CR VlMe 10.4.2008
$smarty->assign("IMAGE_PATH",$image_path);
$smarty->assign("THEME_PATH",$theme_path);
$smarty->assign("MODULE",$currentModule);


//Retreive the list from Database
if($currentModule == 'PriceBooks')
{
	$productid=$_REQUEST['productid'];
	$currency_id=$_REQUEST['currencyid'];
	if($currency_id == null) $currency_id = fetchCurrency($current_user->id);
	$query = 'select vtiger_pricebook.*, vtiger_pricebookproductrel.productid, vtiger_pricebookproductrel.listprice, ' .
					'vtiger_crmentity.crmid, vtiger_crmentity.smownerid, vtiger_crmentity.modifiedtime ' .
					'from vtiger_pricebook inner join vtiger_pricebookproductrel on vtiger_pricebookproductrel.pricebookid = vtiger_pricebook.pricebookid ' .
					'inner join vtiger_crmentity on vtiger_crmentity.crmid = vtiger_pricebook.pricebookid ' .
					'where vtiger_pricebookproductrel.productid='.$adb->sql_escape_string($productid).' and vtiger_crmentity.deleted=0 ' .
							'and vtiger_pricebook.currency_id='.$adb->sql_escape_string($currency_id).' and vtiger_pricebook.active=1';
	$construct_query=false;
}
//ds@8 project tool
elseif ($currentModule == 'Users' && $_REQUEST["mode"] == 'projectleader') {
	$query = "select id,user_name,first_name,last_name,email1,phone_mobile,phone_work,is_admin,status 
          from vtiger_users
          inner join vtiger_user2role 
            ON vtiger_user2role.userid=vtiger_users.id 
          LEFT JOIN vtiger_role2profile 
            ON vtiger_role2profile.roleid = vtiger_user2role.roleid
          LEFT JOIN vtiger_profile2standardperm
            ON vtiger_profile2standardperm.profileid = vtiger_role2profile.profileid  
          WHERE vtiger_profile2standardperm.tabid = ".getTabId('Projects')." 
          AND vtiger_profile2standardperm.Operation = '2' 
          AND vtiger_profile2standardperm.permissions = '0' 
          AND deleted=0 AND vtiger_users.status ='Active'";
	$_REQUEST['order_by'] = 'vtiger_users.id';
	$smarty->assign("MODE",$_REQUEST['mode']);
	$construct_query=false;
}//ds@8e project tool e
else
{
	$construct_query=true;
	if(isset($_REQUEST['recordid']) && $_REQUEST['recordid'] != '')
	{		
		$smarty->assign("RECORDID",$_REQUEST['recordid']);
		$url_string .='&recordid='.$_REQUEST['recordid'];
        	$where_relquery = getRelCheckquery($currentModule,$_REQUEST['return_module'],$_REQUEST['recordid']);
	}
	if(isset($_REQUEST['relmod_id']) || isset($_REQUEST['fromPotential']))
	{
		if($_REQUEST['relmod_id'] !='')
		{
			$mod = $_REQUEST['parent_module'];
			$id = $_REQUEST['relmod_id'];
		}
		else if($_REQUEST['fromPotential'] != '')
		{
			$mod = "Accounts";
			$id= $_REQUEST['acc_id'];
		}

		$smarty->assign("mod_var_name", "parent_module");
		$smarty->assign("mod_var_value", $mod);
		$smarty->assign("recid_var_name", "relmod_id");
		$smarty->assign("recid_var_value",$id);
		$where_relquery.= getPopupCheckquery($currentModule,$mod,$id);
	}
	else if(isset($_REQUEST['task_relmod_id']))
	{
		$smarty->assign("mod_var_name", "task_parent_module");
		$smarty->assign("mod_var_value", $_REQUEST['task_parent_module']);
		$smarty->assign("recid_var_name", "task_relmod_id");
		$smarty->assign("recid_var_value",$_REQUEST['task_relmod_id']);
		$where_relquery.= getPopupCheckquery($currentModule,$_REQUEST['task_parent_module'],$_REQUEST['task_relmod_id']);
	}
    //sk@2
	if($currentModule == 'HelpDesk' && trim($_REQUEST['stopids'],":")!=''){
	    $where_relquery .= " and vtiger_troubletickets.ticketid not in (".str_replace(":",",",trim($_REQUEST['stopids'],":")).")";
	}
	//sk@2e
	if($currentModule == 'Products' && !$_REQUEST['record_id'] && ($popuptype == 'inventory_prod' || $popuptype == 'inventory_prod_po'))
       		$where_relquery .=" and vtiger_products.discontinued <> 0 AND (vtiger_products.productid NOT IN (SELECT crmid FROM vtiger_seproductsrel WHERE setype='Products'))";
	elseif($currentModule == 'Products' && $_REQUEST['record_id'] && ($popuptype == 'inventory_prod' || $popuptype == 'inventory_prod_po'))
        	$where_relquery .=" and vtiger_products.discontinued <> 0 AND (vtiger_products.productid IN (SELECT crmid FROM vtiger_seproductsrel WHERE setype='Products' AND productid=".$adb->sql_escape_string($_REQUEST['record_id'])."))";
	elseif($currentModule == 'Products' && $_REQUEST['return_module'] != 'Products')
       		$where_relquery .=" and vtiger_products.discontinued <> 0";
       		
	if($_REQUEST['return_module'] == 'Products' && $currentModule == 'Products' && $_REQUEST['recordid'])
       	$where_relquery .=" and vtiger_products.discontinued <> 0 AND (vtiger_crmentity.crmid NOT IN (".$adb->sql_escape_string($_REQUEST['recordid']).") AND vtiger_crmentity.crmid NOT IN (SELECT productid FROM vtiger_seproductsrel WHERE setype='Products') AND vtiger_crmentity.crmid NOT IN (SELECT crmid FROM vtiger_seproductsrel WHERE setype='Products' AND productid=".$adb->sql_escape_string($_REQUEST['recordid'])."))";
	
	if($currentModule == 'Services' && $popuptype == 'inventory_service') {
		$where_relquery .=" and vtiger_service.discontinued <> 0";
	}
	 
	//Avoiding Current Record to show up in the popups When editing.
	if($currentModule == 'Accounts' && $_REQUEST['recordid']!=''){
		$where_relquery .=" and vtiger_account.accountid!=".$adb->sql_escape_string($_REQUEST['recordid']);
		$smarty->assign("RECORDID",vtlib_purify($_REQUEST['recordid']));
	}
	
	if($currentModule == 'Contacts' && $_REQUEST['recordid']!=''){
		$where_relquery .=" and vtiger_contactdetails.contactid!=".$adb->sql_escape_string($_REQUEST['recordid']);
		$smarty->assign("RECORDID",vtlib_purify($_REQUEST['recordid']));
	}
	
	if($currentModule == 'Users' && $_REQUEST['recordid']!=''){
		$where_relquery .=" and vtiger_users.id!=".$adb->sql_escape_string($_REQUEST['recordid']);
		$smarty->assign("RECORDID",vtlib_purify($_REQUEST['recordid']));
	}
}
if($currentModule == 'Products' && $_REQUEST['record_id'] && ($popuptype == 'inventory_prod' || $popuptype == 'inventory_prod_po'))
{
	$product_name = getProductName($_REQUEST['record_id']);
	$smarty->assign("PRODUCT_NAME", $product_name);
	$smarty->assign("RECORD_ID", vtlib_purify($_REQUEST['record_id']));
}			
//crmv@24577
if(isset($_REQUEST['query']) && $_REQUEST['reset_query'] != 'true'){
//crmv@24577e	
	list($where, $ustring) = split("#@@#",getWhereCondition($currentModule));
	$url_string .="&query=true".$ustring;
}
//ds@8 project tool
if($currentModule == 'Projects' && $_REQUEST['form'] == 'HelpDeskEditView'){
  if(isset($_REQUEST["searchtype"]) && $_REQUEST["searchtype"]=="BasicSearch" && $_REQUEST["type"]=="alpbt"){
	$query .= " and vtiger_projects.project_name like '".$_REQUEST["search_text"]."%'";
  }
}
//ds@8e project tool e
//crmv@16265
if ($popuptype == 'squirrel_mail') {
	$querystr="SELECT fieldid,fieldname,columnname,tablename,fieldlabel FROM vtiger_field WHERE tabid=? and uitype=13 and vtiger_field.presence in (0,2)";
	$queryres = $adb->pquery($querystr, array(getTabid($_REQUEST['module'])));
	//Change this index 0 - to get the vtiger_fieldid based on email or yahooid
	if ($queryres && $adb->num_rows($queryres) > 0) {
		$fieldid = $adb->query_result($queryres,0,'fieldid');
		$fieldname = $adb->query_result($queryres,0,'fieldname');
		$columnname = $adb->query_result($queryres,0,'columnname');
		$tablename = $adb->query_result($queryres,0,'tablename');
		$fieldlabel = $adb->query_result($queryres,0,'fieldlabel');
	
		$squirrel_mails = Zend_Json::decode(urldecode($_REQUEST['squirrelmails']));
		//crmv@24577
		if($squirrel_mails['from'] != ''  && $_REQUEST['reset_query']!= 'true') {
		//crmv@24577e	
			$smarty->assign("SQUIRREL_SEARCH_FIELD",$fieldname);
			$smarty->assign("SQUIRREL_SEARCH_VALUE",$squirrel_mails['from']);
		}
	}
	$smarty->assign("SQUIRRELVALUES",urlencode($_REQUEST['squirrelvalues']));
	$smarty->assign("SQUIRRELMAILS",urlencode($_REQUEST['squirrelmails']));
	
	$squirrelval = Zend_Json::decode(urldecode($_REQUEST['squirrelvalues']));
	$tmp = getRelationEmailInfo($currentModule,$squirrelval['passed_id'],true);
	//crmv@24577
	if ($tmp && $adb->num_rows($tmp)>0 && $_REQUEST['reset_query']!= 'true') {
	//crmv@24577e	
		$tmp_el = array();
		while($row=$adb->fetchByAssoc($tmp))
			$tmp_el[] = $row[$focus->table_index];
	}
	if (is_array($tmp_el))	// se la mail e' gia' stata collegata non mostro piu' il record
		$where_relquery .= " and $focus->table_name.$focus->table_index not in (".implode(',',$tmp_el).")";
}
//crmv@16265e
if ($construct_query){
	if(isset($where) && $where != '')
	{
		$where_relquery .= ' and '.$where;
	}
	$query = getListQuery($currentModule,$where_relquery);
	$query_count = getListQuery($currentModule,$where_relquery);	
}
else {
	if(isset($where) && $where != '')
	{
		$where_relquery .= ' and '.$where;
	}
	$query .= $where_relquery;
	$query_count = $query.$where_relquery;
}

// vtlib customization: To override module specific popup query for a given field
$override_query = false;
if(method_exists($focus, 'getQueryByModuleField')) {
	$override_query = $focus->getQueryByModuleField(vtlib_purify($_REQUEST['srcmodule']), vtlib_purify($_REQUEST['forfield']), vtlib_purify($_REQUEST['forrecord']));
	if($override_query) {
		$query = $override_query;
	}
}
// END
//crmv@sdk-24186
$sdk_file = SDK::getPopupQuery('field',vtlib_purify($_REQUEST['srcmodule']),vtlib_purify($_REQUEST['forfield']));
if ($sdk_file != '' && Vtiger_Utils::checkFileAccess($sdk_file)) {
	include($sdk_file);
}
$sdk_file = SDK::getPopupQuery('related',vtlib_purify($_REQUEST['return_module']),vtlib_purify($_REQUEST['module']));
if ($sdk_file != '' && Vtiger_Utils::checkFileAccess($sdk_file)) {
	include($sdk_file);
}
//crmv@sdk-24186e
//crmv@11597
//------------------------------------------------------------------------------------------------------------------------------------------
//crmv@popup customview
// Enabling Module Search
$url_string = '';
//crmv@24577
if($_REQUEST['query'] == 'true' && $_REQUEST['reset_query']!= 'true') {
//crmv@24577e	
	list($where, $ustring) = split('#@@#', getWhereCondition($currentModule));
	$url_string .= "&query=true$ustring";
	$smarty->assign('SEARCH_URL', $url_string);
}
// Custom View
$customView = new CustomView($currentModule);
$viewid = $customView->getViewId($currentModule);
$customview_html = $customView->getCustomViewCombo($viewid);
$viewnamedesc = $customView->getCustomViewByCvid($viewid);

// Feature available from 5.1
if(method_exists($customView, 'isPermittedChangeStatus')) {
	// Approving or Denying status-public by the admin in CustomView
	$statusdetails = $customView->isPermittedChangeStatus($viewnamedesc['status']);
	
	// To check if a user is able to edit/delete a CustomView
	$edit_permit = $customView->isPermittedCustomView($viewid,'EditView',$currentModule);
	$delete_permit = $customView->isPermittedCustomView($viewid,'Delete',$currentModule);

	$smarty->assign("CUSTOMVIEW_PERMISSION",$statusdetails);
	$smarty->assign("CV_EDIT_PERMIT",$edit_permit);
	$smarty->assign("CV_DELETE_PERMIT",$delete_permit);
}
// END

$smarty->assign("VIEWID", $viewid);

if($viewnamedesc['viewname'] == 'All') $smarty->assign('ALL', 'All');

if($viewid != "0" && trim($viewid) != '')
{
	$stdfiltersql = $customView->getCVStdFilterSQL($viewid);
	$advfiltersql = $customView->getCVAdvFilterSQL($viewid);
	if(isset($stdfiltersql) && $stdfiltersql != '')
	{
		$list_where .= ' and '.$stdfiltersql;
	}
	if(isset($advfiltersql) && $advfiltersql != '')
	{
		$list_where .= ' and '.$advfiltersql;
	}
	$list_query = $customView->getModifiedCvListQuery($viewid,$query,$currentModule,$popuptype);
}
else {
	$list_query = $query;
}
$smarty->assign("CUSTOMVIEW_OPTION",$customview_html);
//crmv@popup customview end
//------------------------------------------------------------------------------------------------------------------------------------------
//crmv@sdk-18508
$sdk_files = SDK::getViews($module,'popup_query');
if (!empty($sdk_files)) {
	foreach($sdk_files as $sdk_file) {
		include($sdk_file['src']);
	}
}
//crmv@sdk-18508e
$smarty->assign("CUSTOMCOUNTS_OPTION", get_selection_options($noofrows));//ds@3s pulldown selection
$list_max_entries_per_page=get_selection_options($noofrows,'list');
if ($_REQUEST['calc_nav'] == 'true'){
	//Retreive the List View Table Header
	if($viewid !='')
	$url_string .= "&viewname=".$viewid;
	echo '&#&#&#';
	echo get_navigation_values($list_query,$url_string,$currentModule,'',false,$viewid);
	die();
}
if ($_REQUEST['ajax'] == 'true' 
	&& $_REQUEST['search']!= 'true' 
	&& $_REQUEST['changecount']!= 'true'
	&& $_REQUEST['changecustomview']!= 'true')
	{
	if ($_REQUEST['noofrows'] != '')
		$noofrows = $_REQUEST['noofrows'];
	elseif ($_SESSION["lvs"][$currentModule][$viewid]["noofrows"] != ''){	
		$noofrows = $_SESSION["lvs"][$currentModule][$viewid]["noofrows"];
	}
	if ($noofrows > 0){ 
		$list_max_entries_per_page=get_selection_options($noofrows,'list');
		$queryMode = (isset($_REQUEST['query']) && $_REQUEST['query'] == 'true');
		$start = ListViewSession::getRequestCurrentPage($currentModule, $list_query, $viewid, $queryMode);
		$navigation_array = VT_getSimpleNavigationValues($start,$list_max_entries_per_page,$noofrows);
		$limit_start_rec = ($start-1) * $list_max_entries_per_page;
		$record_string = getRecordRangeMessage($list_max_entries_per_page, $limit_start_rec,$noofrows);
		$navigationOutput = getTableHeaderSimpleNavigation($navigation_array, $url_string,$currentModule,$type,$viewid);
		$smarty->assign("RECORD_COUNTS", $record_string);
		$smarty->assign("NAVIGATION", $navigationOutput);
		$smarty->assign("AJAX", 'true');
	}
}
else {
	$queryMode = (isset($_REQUEST['query']) && $_REQUEST['query'] == 'true');
	$start = ListViewSession::getRequestCurrentPage($currentModule, $list_query, $viewid, $queryMode);
	$limit_start_rec = ($start-1) * $list_max_entries_per_page;
	if ($limit_start_rec >= $list_max_entries_per_page){
		 $start -= 1;
		 $limit_start_rec = ($start-1) * $list_max_entries_per_page;
		 $_SESSION['lvs'][$currentModule][$viewid]['start'] = $start;
	}		
	$navigation_array['current'] = $start;
	$navigation_array['start'] = $start;
}
$list_result = $adb->limitQuery($list_query,$limit_start_rec,$list_max_entries_per_page);
//crmv@11597 e
//Retreive the List View Table Header

$focus->list_mode="search";
$focus->popup_type=$popuptype;
$url_string .='&popuptype='.$popuptype;
if(isset($_REQUEST['select']) && $_REQUEST['select'] == 'enable')
	$url_string .='&select=enable';
if(isset($_REQUEST['return_module']) && $_REQUEST['return_module'] != '')
	$url_string .='&return_module='.$_REQUEST['return_module'];
$listview_header_search=getSearchListHeaderValues($focus,"$currentModule",$url_string,$sorder,$order_by,$relatedlist,$customView);
//crmv@16265
$listview_header_search[$fieldname] = getTranslatedString($fieldlabel,$_REQUEST['module']);
//crmv@16265e
$smarty->assign("SEARCHLISTHEADER", $listview_header_search);


$listview_header = getSearchListViewHeader($focus,"$currentModule",$url_string,$sorder,$order_by,$customView);
$smarty->assign("LISTHEADER", $listview_header);
$smarty->assign("HEADERCOUNT",count($listview_header)+1);

$listview_entries = getSearchListViewEntries($focus,"$currentModule",$list_result,$navigation_array,'',$customView);
//ds@8 project tool
if($currentModule == 'Projects' && $_REQUEST['form'] == 'HelpDeskEditView'){
  if($_REQUEST["popuptype"]!="more"){
	if(isset($_REQUEST["record"]) && $_REQUEST["record"]!=""){
	  $projects_result = $adb->query('select * from vtiger_projects_tickets where ticket_id='.$_REQUEST['record']);
	  $projects_noofrows = $adb->num_rows($projects_result);
	  if($projects_noofrows > 0){
		for($i=0;$i<$projects_noofrows;$i++){
		  $project_id = $adb->query_result($projects_result,$i,'project_id');
		  $Projects[$project_id] = 1;
		}
	  }
	  $smarty->assign("PROJECT_CHECK",$Projects);
	}
	foreach($listview_entries as $projectid=>$HelpArray){
	  $Exploded = explode(">",$listview_entries[$projectid][0]);
	  list($project_name, $throw) = explode("<",$Exploded[1]);
	  $ProjectArr[$projectid]=$project_name;
	  if(is_numeric(strpos($HelpArray[0], "set_return(")))
		$listview_entries[$projectid][0] = str_replace("set_return(", "set_return_tickets(", $listview_entries[$projectid][0]);
	}
	$smarty->assign("PROJECT_NAME_ARR",$ProjectArr);
  }
  $smarty->assign("ADD_TO_URL","&form=HelpDeskEditView&record=".$_REQUEST["record"]);
}
//ds@8e project tool
$smarty->assign("LISTENTITY", $listview_entries);

$smarty->assign("DATEFORMAT",$current_user->date_format);
$smarty->assign("RECORD_COUNTS", $record_string);
$smarty->assign("POPUPTYPE", $popuptype);
//crmv@17997
$queryGenerator = new QueryGenerator($currentModule, $current_user);
$controller = new ListViewController($adb, $current_user, $queryGenerator);
$alphabetical = AlphabeticalSearch($currentModule,'index',$focus->search_base_field,'true','basic',"","","","",$viewid);
$fieldnames = $controller->getAdvancedSearchOptionString(true);
//crmv@17997 end
$criteria = getcriteria_options();
$smarty->assign("CRITERIA", $criteria);
$smarty->assign("FIELDNAMES", $fieldnames);
$smarty->assign("ALPHABETICAL", $alphabetical);
if (isset($_REQUEST["selected_ids"]))
{
  $smarty->assign("SELECTED_IDS_ARRAY", explode(";",$_REQUEST["selected_ids"]));
  $smarty->assign("SELECTED_IDS", $_REQUEST["selected_ids"]);
} 
if (isset($_REQUEST["all_ids"]))
{
  $smarty->assign("ALL_IDS", $_REQUEST["all_ids"]);
}
//crmv@16265 : QuickCreatePopup		//crmv@20702
$qc_module = getQuickCreateModules($currentModule);
if(!empty($qc_module))
	$smarty->assign('QUICKCREATE','permitted');
//crmv@16265e	//crmv@20702e

//crmv@sdk-18501
include_once('vtlib/Vtiger/Link.php');
$hdrcustomlink_params = Array('MODULE'=>$currentModule);
$COMMONHDRLINKS = Vtiger_Link::getAllByType(Vtiger_Link::IGNORE_MODULE, Array('HEADERLINK','HEADERSCRIPT', 'HEADERCSS'), $hdrcustomlink_params);
$smarty->assign('HEADERLINKS', $COMMONHDRLINKS['HEADERLINK']);
$smarty->assign('HEADERSCRIPTS', $COMMONHDRLINKS['HEADERSCRIPT']);
$smarty->assign('HEADERCSS', $COMMONHDRLINKS['HEADERCSS']);
//crmv@sdk-18501 e

if(isset($_REQUEST['ajax']) && $_REQUEST['ajax'] != '')
	$smarty->display("PopupContents.tpl");
else
	$smarty->display("Popup.tpl");

?>